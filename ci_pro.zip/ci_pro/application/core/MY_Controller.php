<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	public function __construct(){
		parent::__construct();
		// Load API helper
		// $this->load->helper('api');
		// Check authorization for api_key

		// Set form validation error message html tag
		$this->form_validation->set_error_delimiters('', '');
	}

	// Authorise api_key
	public function appAuth($requestedKey){

		if($requestedKey != APIKEY || $requestedKey == ''){
 			echo $this->output_json(array('status' =>  "error" , 'result' => 'Unauthorized Access'), 401);exit;
		}
	}

	// output json response
	public function output_json( $array = array(), $status_codes = '200' ){
		if ($status_codes != '') {
			$this->output->set_status_header( $status_codes );
			$this->output->set_content_type('application/json')
						 ->set_output(
						 	json_encode(
						 		$array
						 	)
						 );

			return	$string = $this->output->get_output();
		}
	}
}

/* the MY_API_Controller class */
class  MY_API_Controller extends CI_Controller{
	public function __construct(){
		parent::__construct();

		if($_SERVER['REQUEST_METHOD'] == "OPTIONS") {
			$allowedOrigin = $_SERVER['HTTP_ORIGIN'];
		    header('Access-Control-Allow-Origin: ' . $allowedOrigin);
		    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
		    header('Access-Control-Allow-Headers: Auth-Token, content-type');
		    header('Access-Control-Max-Age: 1728000');
		    exit;
		}
		//header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Headers: content-type, auth-token");

		// Check authorization for api_key
		$this->runBefore();

		// Set form validation error message html tag
		$this->form_validation->set_error_delimiters('', '');
	}

	protected function runBefore(){
		// Check authorization for api_keyAuth-Token
		$this->appAuth( $this->input->get_request_header('Auth-Token', TRUE) );
	}


	// Authorise api_key
	public function appAuth($requestedKey){

		if($requestedKey != APIKEY || $requestedKey == ''){
 			echo $this->output_json(array('status' =>  "error" , 'result' => 'Unauthorized Access'), 401);exit;
		}
	}

	// output json response
	public function output_json( $array = array(), $status_codes = '' ){

		if ($status_codes != '') {
			$this->output->set_status_header( $status_codes );
			$this->output->set_content_type('application/json')
						 	->set_output(json_encode($array));
			return	$string = $this->output->get_output();
		}
	}
}
// END CLASS