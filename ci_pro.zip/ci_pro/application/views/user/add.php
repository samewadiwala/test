<div class="inner_main">
	<form id="UserForm" class="UserForm form-vertical" action="<?php echo $formAction;?>" method="post">
	<div class="form_page user_details">
		<div class="fl_w mrgbtm15">
			<div class="add_user">
				<input type="submit" name="submit" class="btn" value="save">
				<button type="button" class="btn close_btn backtoIndex" data-dismiss="modal">Cancel</button>									
			</div>
		</div>
		<div class="fl_w">
			<div class="row">
				<div class="col-sm-6">
					<?php $formAction = is_numeric($id) ? base_url().'user/edit/'.$id : base_url().'user/add';?>
					
						<div class="head_cover">
							<h2 class="tbl_title">User Detail</h2>						
						</div>
						<div class="error_div"></div>
						<?php echo _errors();?>
	          			<?php validateErrors(); ?>
						<div class="form_cnt">
							<div class="form-group">
								<label>User Name</label>
								<input type="text" class="form-control" name="user[userName]" value="<?php echo setValue($userData,'email','email')?>">
								<input type="hidden" class="mode" name="mode" value="<?php echo is_numeric($id) ? 'Edit' : 'Add';?>">
		            			<input type="hidden" id="id" name="id" value="<?php echo setValue($userData, 'id', 'id'); ?>">

							</div>
							<div class="form-group">
								<label for="password">*Password <a class="viewpassword" href="javascript:void(0)"><i class="fas fa-eye changeicon"></i></a></label>
								<input type="password" class="form-control pswshowhide" name="user[password]" value="">
							</div>
							<div class="form-group">
								<label>First Name</label>
								<input type="text" class="form-control" name="user[firstName]" value="<?php echo setValue($userData,'first_name','first_name')?>">
							</div>
							<div class="form-group">
								<label>Last Name</label>
								<input type="text" class="form-control" name="user[lastName]" value="<?php echo setValue($userData,'last_name','last_name')?>">
							</div>
							<div class="form-group">
								<label>Mobile Number</label>
								<input type="text" class="form-control" name="user[moblieNo]" value="<?php echo setValue($userData,'company','company')?>">
							</div>
						</div>
					
				</div>
				<?php if(is_numeric($id)){ ?>
				<div class="col-sm-6">
					<div class="head_cover">						
						<h2 class="tbl_title">Transactions</h2>
						<div class="add_user">
							<div class="tbl_search">
								<input type="search" class="form-control searchusertrans" placeholder="Search…">
							</div>
							<a class="tbl_add_icon" href="javascript:void(0)" data-toggle="modal" data-target="#tran_bond"><img src="<?php echo base_url(); ?>assets/images/icon-add.png" srcset="<?php echo base_url(); ?>assets/images/icon-add@2x.png 2x"></a>
						</div>
					</div>
					<table width="100%" cellpadding="0" cellspacing="0" class="display trans_pro_tbl responsive nowrap">
						<thead>
							<tr>
								<th width="25%">Date</th>
								<th width="25%">Bond Type</th>
								<th width="25%">Status</th>
								<th width="25%">Action</th>								
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			<?php } ?>
			</div>
		</div>
	</div>
	</form>
</div>
 <script type="text/javascript" src="<?php echo base_url()?>assets/js/page/user/user.js"></script>
<script type="text/javascript">
	 if(userForm != 'undefined') {
        userForm.setup({
            form : $('form#UserForm')
        });
    }
</script>
<!-- Add Bonds -->