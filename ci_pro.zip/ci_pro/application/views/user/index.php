<div class="inner_main">
	<div class="table_main">
		<div class="head_cover">
			<h2 class="tbl_title">User</h2>
			<div class="add_user">
				
				<div class="half_sel">
					<select class="cm_select statusSearch" name="status" data-placeholder="Filter by Status">
						<option value="0" selected>All</option>
						<option value="1">Active</option>
						<option value="2">Hold</option>
					</select>
				</div>							
				<div class="tbl_search">
					<?php  $this->lang->line('welcome_message'); ?>
					<p style="text-align: center; color: #FFFF; "> <?php echo $this->lang->line('welcome_message'); ?></p>
					<input type="search" class="form-control userSearch" placeholder="Search…">
				</div>
				<a class="tbl_add_icon addUserbtn" href="<?php echo base_url(); ?>user/add"><img src="<?php echo base_url(); ?>assets/images/icon-add.png" srcset="<?php echo base_url(); ?>assets/images/icon-add@2x.png 2x"></a>
			</div>
		</div>
		<table width="100%" cellpadding="0" cellspacing="0" class="display user_tbl1 responsive nowrap">
			<thead>
				<tr>
					<th width="10%"><?= $this->lang->line('user'); ?></th>
					<th width="20%">First Name</th>
					<th width="20%">Status</th>
					<th width="20%">Created At</th>
					<th width="20%">Action</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>
</div>

<div class="modal small_popup" id="deleteUsers">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Warning</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p>Are you sure want to delete this user?</p>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <a class="btn btn-success deleteUsers" href="javascript:void(0);">Yes</a>
        <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
      </div>

    </div>
  </div>
</div>
<!-- <script type="text/javascript" src="<?php echo base_url()?>assets/js/page/user_modal.js"></script> -->