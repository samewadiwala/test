<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
 <script type="text/javascript" src="<?php echo base_url()?>assets/js/page/user.js"></script>
