<div class="toogle_icon"><i class="fas fa-bars"></i></div>
<div class="menu_cover">
	<div class="menu">
		<ul>
			<li class="<?php echo $active_class == 'Transaction' ? 'active': ''?>"><a href="<?php echo base_url(); ?>transaction"><img src="<?php echo base_url(); ?>assets/images/icon-transactions.png" srcset="<?php echo base_url(); ?>assets/images/icon-transactions@2x.png 2x">Transactions</a></li>
			<li class="<?php echo $active_class == 'Education' ? 'active': ''?>"><a href="<?php echo base_url(); ?>education"><img src="<?php echo base_url(); ?>assets/images/icon-education.png" srcset="<?php echo base_url(); ?>assets/images/icon-education@2x.png 2x">Education</a></li>
			<li class="<?php echo $active_class == 'Insider' ? 'active': ''?>"><a href="<?php echo base_url(); ?>insider"><img src="<?php echo base_url(); ?>assets/images/icon-insider.png" srcset="<?php echo base_url(); ?>assets/images/icon-insider@2x.png 2x">Insider</a></li>
			<li class="<?php echo $active_class == 'User' ? 'active': ''?>"><a href="<?php echo base_url(); ?>user"><img src="<?php echo base_url(); ?>assets/images/icon-users.png" srcset="<?php echo base_url(); ?>assets/images/icon-users@2x.png 2x">Users</a></li>
		</ul>
		
<p><?php echo $this->lang->line('welcome_message'); ?></p>
	</div>
	<div class="select_box">
		<select class="cm_select headSelect">
			<option value="1"><?php echo getUserData(); ?></option>
			<option value="0">Logout</option>
		</select>
	</div>
</div>