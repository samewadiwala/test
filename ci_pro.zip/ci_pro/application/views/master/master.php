<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Hub - <?php echo $title;?> </title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.css">

    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/select2.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/responsive.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/devloper.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/toastr.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap-datepicker.css">
    <!-- <link rel="stylesheet" href="https://www.malot.fr/bootstrap-datetimepicker/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css"> -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap-datetimepicker.min.css">
    <!-- <link href="<?php echo base_url()?>assets/css/bootstrap-multiselect.css" type="text/css" rel="stylesheet"> -->
    
    <script src="<?php echo base_url()?>assets/js/jquery-1.11.3.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/dt/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/dt/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/dt/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/dt/responsive.bootstrap4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/moment-with-locales.js" type="text/javascript"></script>
    <!-- <script src="https://www.malot.fr/bootstrap-datetimepicker/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js?t=20130302" type="text/javascript"></script> -->
    
    <script src="<?php echo base_url()?>assets/js/daterangepicker.min.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.validate.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.mask.min.js"></script>
    <!-- <script src="<?php echo base_url()?>assets/js/bootstrap-multiselect.js" type="text/javascript"></script> -->
    <script src="<?php echo base_url()?>assets/js/bootstrap-datepicker.js" type="text/javascript"></script>

    <script type="text/javascript">
        var base_url = "<?php echo base_url(); ?>";
    </script>
</head>

<body>
    <header>
        <div class="header_left">
            <div class="logo">
                <a href="<?php echo base_url(); ?>">
                    <img src="<?php echo base_url(); ?>assets/images/HUB-Horizontal-With-Roundel.png" srcset="<?php echo base_url(); ?>assets/images/HUB-Horizontal-With-Roundel@2x.png 2x">
                </a>
            </div>
        </div>
        <div class="header_right">
            <?php // echo $this->load->view('master/header',null,true);?>
            <select onchange="javascript:window.location.href='<?php echo base_url(); ?>LanguageSwitcher/switchLang/'+this.value;">
            <option value="english" <?php if($this->session->userdata('site_lang') == 'english') echo 'selected="selected"'; ?>>English</option>
            <option value="french" <?php if($this->session->userdata('site_lang') == 'french') echo 'selected="selected"'; ?>>French</option>
            <option value="german" <?php if($this->session->userdata('site_lang') == 'german') echo 'selected="selected"'; ?>>German</option>   
        </select>
        </div>
    </header>
    <div class="loadimg" style="display: none">
        <img src="<?php echo base_url() ?>assets/images/loader.gif" style="width: 3%;">
    </div>
    <div class="main">
        <div class="page_inner_div <?php if(isset($inner_class)){ echo $inner_class; }?>">
           <?php echo $content; ?>
        </div>
    </div>
<?php echo $this->load->view('master/footer',null,true);?>
<?php  if(isset($extras)){  echo $extras; } ?>
    <script src="<?php echo base_url()?>assets/js/custom.js"></script>
</body>
</html>