<div class="col-md-3 left_col">
  <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0;">
      <a href="<?php echo base_url() ?>" class="site_title"><i class="fa fa-paw"></i> <span>Prestige</span></a>
    </div>

    <div class="clearfix"></div>

    <!-- menu profile quick info -->
    <div class="profile clearfix">
      <div class="profile_pic">
      </div>
      <div class="profile_info">
        <span>Welcome,</span>
        <h2>Admin</h2>
      </div>
      <div class="clearfix"></div>
    </div>
    <!-- /menu profile quick info -->

    <br />

    <!-- sidebar menu -->
    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
      <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
          <li class="<?php echo $active_class == 'Dashboard' ? 'active': ''?>"><a href="<?php echo base_url()?>" title="Dashboard"><i class="fa fa-tachometer"></i> Dashboard</a>
          </li>
          <li class="<?php echo $active_class == 'bids' ? 'active_menu current-page': ''?>"><a href="<?php echo base_url()?>bids" title="Bid Board"><i class="fa fa-check"></i> Bid Board</a></li>
          <li><a href="javascript:void(0)" title="Quotes"><i class="fa fa-quote-left"></i> Quotes</a></li>
          <li class="<?php echo $active_class == 'Jobs' ? 'active_menu current-page': ''?>"><a href="<?php echo base_url()?>jobs" title="Jobs"><i class="fa fa-table"></i> Jobs</a></li>

          <li class="<?php echo $active_class == 'Products' ? 'active_menu current-page': ''?>"><a href="<?php echo base_url()?>products" title="Products"><i class="fa fa-cart-arrow-down"></i>Products </a></li>
          
          <li class="<?php echo $active_class == 'Inventory' ? 'active_menu current-page': ''?>"><a href="<?php echo base_url()?>products/inventory" title="Inventory"><i class="fa fa-recycle"></i> Inventory</a></li>
          
          <li class="<?php echo $active_class == 'Customers' ? 'active_menu current-page': ''?>"><a href="<?php echo base_url()?>customers" title="Customers"><i class="fa fa-users"></i> Customers</a></li>
          
          <li><a href="javascript:void(0)" title="Receiving"><i class="fa fa-truck"></i> Receiving</a></li>
          
          <li><a href="javascript:void(0)" title="Account"><i class="fa fa-th-large"></i> Account</a></li>
          
          <li class="<?php echo $active_class == 'settings' ? 'active_menu': ''?>"><a href="<?php echo base_url()?>settings" title="Settings"><i class="fa fa-cog"></i> Settings</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>