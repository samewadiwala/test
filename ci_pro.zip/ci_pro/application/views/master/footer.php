<script type="text/javascript">
  $(document).ready(function() {

    toastr.options = {
      "closeButton": false,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-bottom-right",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "300",
      "hideDuration": "1000",
      "timeOut": "2500",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
   <?php if($this->session->flashdata('success')){ ?>
      Command: toastr["success"]("<?php echo $this->session->flashdata('success'); ?>");
    <?php } ?>
  });
</script>