<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// print array
function pr($array) {
	echo "<pre>";
	print_r($array);
	echo "</pre>";
}
// Check status
function isChecked($status){
	return $status == 1 ? 'checked' : '';
}

// Check status
function isActive($status){
	return $status == 1 ? 'Active' : 'Inactive';
}

// Validate errors
function render_validate_errors(){
	//return array_filter(explode("\n", validation_errors()));
	return array_filter(explode("\n", validation_errors()));
}

//Admin Email Configurations
function emailConfiguration($config = array()){
    $config['useragent'] = 'CodeIgniter';
    $config['protocol'] = 'smtp';
    //$config['mailpath'] = '/usr/sbin/sendmail';
    $config['smtp_host'] = 'smtp.sendgrid.net';
    $config['smtp_user'] = 'apikey';
    $config['smtp_pass'] = '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';
    $config['smtp_port'] = 587;
    $config['mailtype'] = 'html';
    $config['newline'] = "\r\n";
    $config['crlf'] = "\r\n";
    return $config;
}
function strip_tags_content($text) {
	$text = strip_tags($text);
	$new = trim($text);
	return character_limiter($new, 50);
}

function mysubstr($status){
	return substr($status,0,50);
}

function readMoreHelper($string, $chars = 50) {
	return strlen($string) >= $chars ? substr($string, 0, $chars-5) . ' ...' :
$string;
}
// Send mail via admin
function sendMailViaAdmin($toEmail,$subject,$mailContent,$attachment='') {
    $CI =& get_instance();
	$emailConfig = emailConfiguration();

	$emailConfig['mailtype'] = 'html';
	$emailConfig['charset'] = 'iso-8859-1';

	$CI->email->initialize($emailConfig);

	$fromName = 'Hub';
	$CI->email->from('admin@hub.com', $fromName);
	$CI->email->to($toEmail);
	// $CI->email->cc($ccEmail);
	$CI->email->subject($subject);
	$CI->email->message($mailContent);
	if ( $attachment != '') {
		$CI->email->attach($attachment);
	}
	$send = $CI->email->send();

	if($send){
		return true;
	}else{
		return false;
	}
}
 
// Validation errors
function validateErrors(){
	$msg = '';
	if(validation_errors()){
		$msg .= "<div class='ci_error_msg alert alert-danger'>";
		$msg .= nl2br(validation_errors());
		$msg .= "</div>";
		echo $msg;
	}
}

// Warnings error
function warnings(){
	$CI =& get_instance();
	$warnings = array();
	if($CI->session->flashdata('warning')){
		$warnings = $CI->session->flashdata('warning');
	}
	return $warnings;
}
function _success($message){
    if ($message != '') {
        return '<div class="alert alert-success">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                        <i class="fa fa-check sign"></i><strong> Success! </strong> ' . $message . '
                    </div>';
    }
    return '';
}
function _errorValid($message){
    if ($message != '') {
        return '<div class="ci_error_msg alert alert-danger">' . $message . '</div>';
    }
    return '';
}

// Error or success message html
function _errors(){

	$CI =& get_instance();
	$CI->session->flashdata('error');
	$message = '';
	if($CI->session->flashdata('ci_validate_errors')){
		$message .= "<div class='ci_error_msg alert alert-danger'>";
		$message .= $CI->session->flashdata('ci_validate_errors');
		$message .= "</div>";
	}
	if($CI->session->flashdata('success')){
		$message = '<div class="alert alert-success">
						<a href="#" class="close" data-dismiss="alert" aria-label="close"> ×</a> <span class="success-span"><i class="fa fa-check" aria-hidden="true"></i></span> ' . $CI->session->flashdata('success'). '
        			</div>';
	}

	if($CI->session->flashdata('error')){
		$message = '<div class="alert alert-danger">
			            <a href="#" class="close" data-dismiss="alert" aria-label="close"> ×</a> <span class="danger-span"></span> ' . $CI->session->flashdata('error'). '
			        </div>';
	}
	return $message;
}

// Check if user is logged in and if logged in redirect to dashboard page
function authAdminLogin(){
	$CI =& get_instance();
	if($CI->session->userdata('hub_admin_session')){
		redirect(base_url().'dashboard');exit;
	}
}

// Check admin session
function checkadminSession(){
	$CI =& get_instance();
	if(!$CI->session->userdata('hub_admin_session')){
		redirect(base_url());exit;
	}
}
function convert2YMD($date=''){
  $var = $date;
  $date = str_replace('-', '/', $var);
  return date('Y-m-d', strtotime($date));
}
function convert2MDY($date=''){
  $var = $date;
  $date = str_replace('-', '/', $var);
  return date('m/d/Y', strtotime($date));
}

// Set Value in form
function setValue($array = array(), $field = '', $ruleField = '', $defaultVal = ''){
	$second = '';
	if ($field != '' && $ruleField != '') {
		if (!empty($array) && $field != '') {
			if (is_array($array)) {
				if (isset($array[$field]) && $array[$field] != '') {
					$second = $array[$field];
				}
			}else{
				if (isset($array->{$field}) && $array->{$field} != '') {
					$second = $array->{$field};
				}
			}
		}
	}

	$set_value = set_value($ruleField, $second);
	return $set_value ? $set_value : $defaultVal;
}

// Make blank file in directory
function mkBlankFile($fileName) {
    $myfile=fopen($fileName,
    "w");
    $txt="403 Forbidden \n Directory access is forbidden.";
    fwrite($myfile,
    $txt);
    fclose($myfile);
}
function clean_special_characters($string) {
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}
// Image upload function
function do_upload($con) {
    $CI=& get_instance();
    $config['file_name']=time() . '_' . clean_special_characters($_FILES[$con['fileName']]["name"]);
    $config['upload_path']=$con['path'];
    $config['allowed_types']=$con['allowType'];
    $config['max_size']=$con['maxSize'];
    //$config['max_width'] = '2000';
    //$config['max_height'] = '2000';
    $CI->load->library('upload',
    $config);
    $CI->upload->initialize($config);
    unset($config);
    if (!$CI->upload->do_upload($con['fileName'])) {
        return array('error'=> $CI->upload->display_errors(),
        'status'=> 0);
    }
    else {
        return array('status'=> 1,
        'upload_data'=> $CI->upload->data());
    }
}

// Remove directory
function _rmDir($path) {
    if (is_dir($path)===true) {
        $files=array_diff(scandir($path),
        array('.',
        '..'));
        foreach ($files as $file) {
            _rmDir(realpath($path) . '/' . $file);
        }
        return rmdir($path);
    }
    else if (is_file($path)===true) {
        return unlink($path);
    }
    return false;
}

// Resize image
function resize_image($con) {
    $CI=& get_instance();
    //$CI->image_lib->clear();
    $config['image_library']='gd2';
    $config['source_image']=$con['sourcePath'];
    $config['new_image']=$con['desPath'];
    $config['quality']='100%';
    $config['create_thumb']=TRUE;
    $config['maintain_ratio']=true;
    $config['thumb_marker']='';
    $config['width']=$con['w'];
    $config['height']=$con['h'];
    $CI->load->library('image_lib',
    $config);
    $CI->image_lib->initialize($config);
    if ($CI->image_lib->resize()) {
        if(isset($con['removeSourceimage']) && $con['removeSourceimage']==true) {
            unlink($con['sourcePath']);
            $CI->image_lib->clear();
        }
        return true;
    } else{
        return false;
    }
}

// Make directory
function _mkDir($path) {
    if (!is_dir($path)) {
        mkdir($path,0755,true);
        mkBlankFile($path.'index.html');
    }
}

function removeOneFile( $fileName ){
	$bool = false;
	if ( @file_exists( $fileName ) ) {
		$bool = @unlink( $fileName );
	}
	return $bool;
}
function setId($id){
	$html = sprintf('%02d',$id);
	return $html;
}
function exportTXT( $filename, $titleArrOne = array(), $dataArr ){
	$ll = '';
	foreach ($dataArr as $key => $value) {
        // fputcsv($handle, array_values($value)). "\n";
        $ll .= implode(', ', array_values($value)). "\r\n";
    }
  	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$filename.".txt");
	header("Pragma: no-cache");
	header("Expires: 0");
	print $ll;
	exit;
}
function exportCSV( $filename, $titleArrOne = array(), $dataArr ){
	header("Content-type: text/html");
	header("Content-Disposition: attachment; filename=".$filename.".txt");
	header("Pragma: no-cache");
	header("Expires: 0");

	$handle = fopen('php://output', 'w');
	fputcsv($handle, $titleArrOne);
 	foreach ($dataArr as $key => $value) {
        fputcsv($handle, array_values($value));
    }
    fclose($handle);
	exit;
}

function array_insert(&$array, $position, $insert)
{
    if (is_int($position)) {
        array_splice($array, $position, 0, $insert);
    } else {
        $pos   = array_search($position, array_keys($array));
        $array = array_merge(
            array_slice($array, 0, $pos),
            $insert,
            array_slice($array, $pos)
        );
    }
}

// get values in array
function getValuesInArray($valArray){
	$array = [];
	foreach ($valArray as $keys => $values) {
		foreach ($values as $key => $value) {
			if($value != ''){
				$array[] = $value;
			}
		}
	}
	return $array;
}
function educationImageUpload($fileName = 'documents', $removeSourceImage = false) {
    ////////////Image Upload start////////
    $documentsImagePath = EDUCATION_UPLOAD_DIR  . '/';
    $documentsThumbImagePath = EDUCATION_UPLOAD_DIR  . '/thumb/';
    _mkDir($documentsImagePath);
    _mkDir($documentsThumbImagePath);
    $imageConfig['fileName'] = $fileName;
    $imageConfig['path'] = $documentsImagePath;

    $imageConfig['allowType'] = 'gif|jpg|jpeg|png|avi|mp4|3gp|flv|doc|docx|pdf|xls|xlsx|csv|doc|docx|ppt|pptx|txt|xlsx|tiff';
    //$imageConfig['maxSize'] = '15048';
    $imageConfig['maxSize'] = 0;
    $imageResult = do_upload($imageConfig);
    if($imageResult) {
        $uploadeImgName = $imageResult['upload_data']['file_name'];
        // resize image
        $imageResizeConfig['w'] = '150';
        $imageResizeConfig['h'] = '125';
        $imageResizeConfig['sourcePath'] = $documentsImagePath.$uploadeImgName;
        $imageResizeConfig['desPath'] = $documentsThumbImagePath;
        $imageResizeConfig['removeSourceimage'] = $removeSourceImage;
        $imageResizeResult = resize_image($imageResizeConfig);
        if($imageResult) {
            return $imageResult;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
    ////////////Image Upload End//////////
}

function insiderImageUpload($fileName = 'documents', $removeSourceImage = false) {
    ////////////Image Upload start////////
    $documentsImagePath = INSIDER_UPLOAD_DIR  . '/';
    $documentsThumbImagePath = INSIDER_UPLOAD_DIR  . '/thumb/';
    _mkDir($documentsImagePath);
    _mkDir($documentsThumbImagePath);
    $imageConfig['fileName'] = $fileName;
    $imageConfig['path'] = $documentsImagePath;

    $imageConfig['allowType'] = 'gif|jpg|jpeg|png|avi|mp4|3gp|flv|doc|docx|pdf|xls|xlsx|csv|doc|docx|ppt|pptx|txt|xlsx|tiff';
    $imageConfig['maxSize'] = '15048';
    $imageResult = do_upload($imageConfig);
    if($imageResult) {
        $uploadeImgName = $imageResult['upload_data']['file_name'];
        // resize image
        $imageResizeConfig['w'] = '150';
        $imageResizeConfig['h'] = '125';
        $imageResizeConfig['sourcePath'] = $documentsImagePath.$uploadeImgName;
        $imageResizeConfig['desPath'] = $documentsThumbImagePath;
        $imageResizeConfig['removeSourceimage'] = $removeSourceImage;
        $imageResizeResult = resize_image($imageResizeConfig);
        if($imageResult) {
            return $imageResult;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
    ////////////Image Upload End//////////
}
function transactionImageUpload($fileName = 'documents', $removeSourceImage = false) {
    ////////////Image Upload start////////
    $documentsImagePath = TRANSACTON_UPLOAD_DIR  . '/';
    $documentsThumbImagePath = TRANSACTON_UPLOAD_DIR  . '/thumb/';
    _mkDir($documentsImagePath);
    _mkDir($documentsThumbImagePath);
    $imageConfig['fileName'] = $fileName;
    $imageConfig['path'] = $documentsImagePath;

    $imageConfig['allowType'] = 'gif|jpg|jpeg|png|avi|mp4|3gp|flv|doc|docx|pdf|xls|xlsx|csv|doc|docx|ppt|pptx|txt|xlsx';
    $imageConfig['maxSize'] = '15048';
    $imageResult = do_upload($imageConfig);
    if($imageResult) {
        $uploadeImgName = $imageResult['upload_data']['file_name'];
        // resize image
        $imageResizeConfig['w'] = '150';
        $imageResizeConfig['h'] = '125';
        $imageResizeConfig['sourcePath'] = $documentsImagePath.$uploadeImgName;
        $imageResizeConfig['desPath'] = $documentsThumbImagePath;
        $imageResizeConfig['removeSourceimage'] = $removeSourceImage;
        $imageResizeResult = resize_image($imageResizeConfig);
        if($imageResult) {
            return $imageResult;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
    ////////////Image Upload End//////////
}
function bondtransactionstatus($status = NULL){
    $array = array(
        1 => 'Submitted',
        2 => 'Processed',
        3 => 'Cancelled',        
    );
    if($status != ""){
        if (isset($array[$status])) {
            return $array[$status];
        }
        return "";
    }else{
        return $array;
    }
    return $array;
}
function allStateList($status=''){

        $array = array(
            'AL' => 'Alabama',
            'AK' => 'Alaska',
            'AZ' => 'Arizona',
            'AR' => 'Arkansas',
            'CA' => 'California',
            'CO' => 'Colorado',
            'CT' => 'Connecticut',
            'DE' => 'Delaware',
            'FL' => 'Florida',
            'GA' => 'Georgia',
            'HI' => 'Hawaii',
            'ID' => 'Idaho',
            'IL' => 'Illinois',
            'IN' => 'Indiana',
            'IA' => 'Iowa',
            'KS' => 'Kansas',
            'KY' => 'Kentucky',
            'LA' => 'Louisiana',
            'ME' => 'Maine',
            'MD' => 'Maryland',
            'MA' => 'Massachusetts',
            'MI' => 'Michigan',
            'MN' => 'Minnesota',
            'MS' => 'Mississippi',
            'MO' => 'Missouri',
            'MT' => 'Montana',
            'NE' => 'Nebraska',
            'NV' => 'Nevada',
            'NH' => 'New Hampshire',
            'NJ' => 'New Jersey',
            'NM' => 'New Mexico',
            'NY' => 'New York',
            'NC' => 'North Carolina',
            'ND' => 'North Dakota',
            'OH' => 'Ohio',
            'OK' => 'Oklahoma',
            'OR' => 'Oregon',
            'PA' => 'Pennsylvania',
            'RI' => 'Rhode Island',
            'SC' => 'South Carolina',
            'SD' => 'South Dakota',
            'TN' => 'Tennessee',
            'TX' => 'Texas',
            'UT' => 'Utah',
            'VT' => 'Vermont',
            'VA' => 'Virginia',
            'WA' => 'Washington',
            'WV' => 'West Virginia',
            'WI' => 'Wisconsin',
            'WY' => 'Wyoming',
        );
    if($status != ""){
        if (isset($array[$status])) {
            return $array[$status];
        }
        return "";
    }else{
        return $array;
    }
    // return $array;
}
function getUserData(){
    $CI =& get_instance();
    $sessionData = $CI->session->userdata('hub_admin_session');
   return $userName = $sessionData->first_name.' '.$sessionData->last_name;
}

function addtableData($tableName, $addData  = array()){
    $CI =& get_instance();
    $CI->load->model('auth_model');
    $id = $CI->auth_model->addTableData($tableName, $addData );
    return $id;
}
function dateFormatChange($date){

  $var = $date;
  $date = str_replace('-', '/', $var);
  //return date('d/m/Y H:i A', strtotime($date));
   return date('m/d/Y', strtotime($date));
}
function checkstatusd($status,$id){
    if($status == 1){
        $statusString = '<div class="table_icon">
                        <div class="table_icon">
                            <a class="edit editBond" data-id="'.$id.'" href="javascript:void(0);"><img src="'.base_url().'assets/images/icon-edit.png" srcset="images/icon-edit@2x.png 2x"></a>
                            <a class="view visible_icon statusBond" data-id="'.$id.'" data-status="'.$status.'" href="javascript:void(0);"><i class="fas fa-eye"></i></a>
                            <a class="delete deleteBonds" data-id="'.$id.'" href="javascript:void(0)"><img src="'.base_url().'assets/images/icon-delete.png" srcset="images/icon-delete@2x.png 2x"></a>
                        </div>
                    </div> ';
    }else{
        $statusString = '<div class="table_icon">
                        <div class="table_icon">
                            <a class="edit editBond" data-id="'.$id.'" href="javascript:void(0);"><img src="'.base_url().'assets/images/icon-edit.png" srcset="images/icon-edit@2x.png 2x"></a>
                            <a class="view visible_icon statusBond" data-id="'.$id.'" data-status="'.$status.'" href="javascript:void(0);"><i class="fas fa-eye-slash"></i></a>
                            <a class="delete deleteBonds" data-id="'.$id.'" href="javascript:void(0)"><img src="'.base_url().'assets/images/icon-delete.png" srcset="images/icon-delete@2x.png 2x"></a>
                        </div>
                    </div> ';
    }
    return $statusString;
}
function changestatus($status,$id,$form){
    if($status == 1){
        $statusString = '<div class="table_icon">
                        <div class="table_icon">
                            <a class="edit edit'.$form.'" data-id="'.$id.'" href="javascript:void(0);"><img src="'.base_url().'assets/images/icon-edit.png" srcset="'.base_url().'assets/images/icon-edit@2x.png 2x"></a>
                            <a class="view visible_icon status'.$form.'" data-id="'.$id.'" data-status="'.$status.'" href="javascript:void(0);"><i class="fas fa-eye"></i></a>
                            <a class="delete delete'.$form.'" data-id="'.$id.'" href="javascript:void(0)"><img src="'.base_url().'assets/images/icon-delete.png" srcset="'.base_url().'assets/images/icon-delete@2x.png 2x"></a>
                        </div>
                    </div> ';
    }else{
        $statusString = '<div class="table_icon">
                        <div class="table_icon">
                            <a class="edit edit'.$form.'" data-id="'.$id.'" href="javascript:void(0);"><img src="'.base_url().'assets/images/icon-edit.png" srcset="'.base_url().'assets/images/icon-edit@2x.png 2x"></a>
                            <a class="view visible_icon status'.$form.'" data-id="'.$id.'" data-status="'.$status.'" href="javascript:void(0);"><i class="fas fa-eye-slash"></i></a>
                            <a class="delete delete'.$form.'" data-id="'.$id.'" href="javascript:void(0)"><img src="'.base_url().'assets/images/icon-delete.png" srcset="'.base_url().'assets/images/icon-delete@2x.png 2x"></a>
                        </div>
                    </div> ';
    }
    return $statusString;
}
function changeLink($bondtype, $id){
    $transaction_url = "transaction/";
    $methodname = "";
    $table = "";
    $$idData="";
    $filename="";
    $CI = get_instance();
    $CI->load->model('transaction_model');
    if($bondtype == "Licence & Permit"){
        $methodname = "licencepermit";
        $table = 'bond_licence';
        $idData = $CI->transaction_model->getTransactionSubData($table,$id);
        $transaction_url .= $methodname.'/'.$idData;
    }else if($bondtype == "Notary Bond"){
        $methodname = "notaryrequest/std";
        $table = 'bond_notary_std';
        $idData = $CI->transaction_model->getTransactionSubData($table,$id);
        $transaction_url .= $methodname.'/'.$idData;
    }else if($bondtype == "Standard Bond"){
        $methodname = "standardrequest";
        $table = 'standard_request';
        $idData = $CI->transaction_model->getTransactionSubData($table,$id);
        $transaction_url .= $methodname.'/'.$idData;
    }
    $data['id'] = $id;
    $transactiondata = $CI->transaction_model->getTransactionData($data);
    if(isset($transactiondata)){
        $filename=$transactiondata[0]->bond_file;
    }
    if($filename != ""){
        $filestring = '<a class="note" href="'.base_url().'uploads/transaction/'.$filename.'" target="_blank"><img src="'.base_url().'assets/images/icon-note.png" srcset="'. base_url().'assets/images/icon-note@2x.png 2x"></a>';
    }else{
        $filestring = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    }
    $statusString = '<div class="table_icon">
                    <div class="table_icon">
                       '.$filestring.' 
                         <a class="editTransaction" href="'.base_url().$transaction_url.'"><img src="'.base_url().'assets/images/icon-edit.png" srcset="'.base_url().'assets/images/icon-edit@2x.png 2x"></a>                               
                        <a class="deleteTransaction" href="javascript:void(0)" data-id="'.$id.'" data-table="'.$table.'"><img src="'.base_url().'assets/images/icon-delete.png" srcset="'.base_url().'assets/images/icon-delete@2x.png 2x"></a>
                    </div>
                </div>';
    return $statusString;
}
function setBondTeamImg($src){
    if($src != ''){
        $htmls = '<img class="table_img" src="'.base_url().'uploads/insider/thumb/'.$src.'">';
    }else{
        $htmls = '<img class="table_img" src="'.base_url().'assets/images/no-image.jpg">';
    }
    return $htmls;
}
function getStateData($data = array()){
    $state = array();
    foreach ($data as $key => $value) {
        foreach($value as $k => $v){
            $id = $value->state_abbreviation;
            $valdata = $value->state_name;
            if($k == "state_abbreviation")
            $state[$id] = $valdata;
        }
    }
    return $state;
}
function getFormattedUserData($data = array()){
    $user = array();
    foreach ($data as $key => $value) {
        foreach($value as $k => $v){
            $id = $value->id;
            $valdata = $value->first_name.$value->last_name;
            $user[$id] = $valdata;
        }
    }
    return $user;
}
function getLoginUserId(){
    $CI =& get_instance();
    $sessionData = $CI->session->userdata('hub_admin_session');
   return $userId = $sessionData->id;
}
function getBondType($val){
    if($val == 1){
        return "Licence & Permit";
    }else if($val == 2){
        return "Notary Bond";
    }else if($val == 3){
        return "Standard Bond";
    }
}
function getStatus($val){
    if($val == 1){
        return "Submitted";
    }else if($val == 2){
        return "Processed";
    }else if($val == 3){
        return "Cancelled";
    }
}
function getUsername($id){
    $CI = get_instance();
    $CI->load->model('transaction_model');
    return $CI->transaction_model->getUserName($id);
   
}
function monthList($id=''){
    $array = array(
        '1' => 'January',
        '2' => 'February',
        '3' => 'March',
        '4' => 'April',
        '5' => 'May',
        '6' => 'June',
        '7' => 'July',
        '8' => 'August',
        '9' => 'September',
        '10' => 'October',
        '11' => 'November',
        '12' => 'December',
    );
    if($id!=""){
        if (array_key_exists($id, $array)) {
            return $array[$id];
        }else{
            return $id;
        }

    }else{
        return $array;
    }
}
if ( ! function_exists('css_url'))
    {
    function css_url()
    {
        $CI =& get_instance();
        return base_url() . $CI->config->item('css_path');
    }
}
if ( ! function_exists('queue_css'))
{
    function queue_css($file, $media='all')
    {
        if(!empty($file)){
            foreach($file as $e) {
                $element = '<link rel="stylesheet" href="' . css_url() . $e . '"';

                foreach ( $atts as $key => $val )
                    $element .= ' ' . $key . '="' . $val . '"';
                $element .= ' />'."\n";
                echo $element;
            }
        }
    }
}

if ( ! function_exists('js_url'))
    {
    function js_url()
    {
        $CI =& get_instance();
        return base_url() . $CI->config->item('js_path');
    }
}
if ( ! function_exists('queue_js'))
{
    function queue_js($file, $atts = array())
    {
       
        if(!empty($file)){
            $element = '<script type="text/javascript" src="' . js_url() . $file . '"';

            foreach ( $atts as $key => $val )
                $element .= ' ' . $key . '="' . $val . '"';
            $element .= '></script>'."\n";

            echo $element;
        }
    }
}

function getStatusData($value='')
{   
    $data = array('1' => 'Active','2' => 'Hold' );

    return $data[$value];
}