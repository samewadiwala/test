<?php
   $lang['welcome_message'] = 'Welcome to Franch';
   $lang['user'] 			= 'Franch user';
?>