<?php
   $lang['msg'] = "CodeIgniter Internationalization example.";
   $lang['welcome_message'] = 'Welcome to German';
   $lang['user'] 			= 'German user';

?>