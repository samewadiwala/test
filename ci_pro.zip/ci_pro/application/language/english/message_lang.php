<?php
   $lang['welcome_message'] = 'Welcome to Englsh';
   $lang['user'] 			= 'Englsh user';
?>