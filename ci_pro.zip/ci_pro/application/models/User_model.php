<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends CI_Model { 
	
	const STATUS_ACTIVE = '1';
    const STATUS_HOLD   = '2';

    const STATUS_ACTIVE_TEXT = 'active';
    const STATUS_HOLD_TEXT   = 'hold';


    function __construct(){
        parent::__construct();
        //$this->load->database();		
    }


    public function dt_ajax_user_get($where = array()){
        $this->datatables->select('u.userName,uf.firstName, u.status, u.created_at, u.id as uid',false);
        $this->datatables->from('user as u');
        $this->datatables->join('userProfile as uf','u.id = uf.userId','LEFT');

        if($where['columns']['3']['search']['value'] != '' && $where['columns']['3']['search']['value'] != '0' ){
            $this->datatables->where('u.status',$where['columns']['3']['search']['value']);
        }
        $this->datatables->edit_column('status','$1','getStatusData(status)');
        $this->datatables->edit_column('created_at','$1','dateFormatChange(created_at)');
        $this->datatables->edit_column('uid', '<div class="table_icon">
                        <div class="table_icon">
                            <a class="edit editUser" data-id="$1" href="'.base_url().'user/edit/$1"><img src="'.base_url().'assets/images/icon-edit.png" srcset="'.base_url().'assets/images/icon-edit@2x.png 2x"></a>                       
                            <a class="delete deleteUser" data-id="$1" href="javascript:void(0)"><img src="'.base_url().'assets/images/icon-delete.png" srcset="'.base_url().'assets/images/icon-delete@2x.png 2x"></a>
                        </div>
                    </div>', 
                'uid'
            )
        ;
        return $this->datatables->generate();
    }

    public function validate($rule = 'Add', $customers_id = ''){
        $ruleConfig = array(
            'Add' => array(
                array(
                    'field' => 'user[userName]',
                    'rules' => 'required|trim',
                    'label' => 'User Name'
                ),
                array(
                    'field' => 'user[firstName]',
                    'rules' => 'required|trim',
                    'label' => 'First Name'
                ),
                array(
                    'field' => 'user[lastName]',
                    'rules' => 'required|trim',
                    'label' => 'Last Name'
                ),
                array(
                    'field' => 'user[moblieNo]',
                    'rules' => 'required|trim',
                    'label' => 'Moblie No'
                )
                
            
            ),
            'Edit' => array(
                array(
                    'field' => 'user[userName]',
                    'rules' => 'required|trim',
                    'label' => 'User Name'
                ),
                array(
                    'field' => 'user[firstName]',
                    'rules' => 'required|trim',
                    'label' => 'First Name'
                ),
                array(
                    'field' => 'user[lastName]',
                    'rules' => 'required|trim',
                    'label' => 'Last Name'
                ),
                array(
                    'field' => 'user[moblieNo]',
                    'rules' => 'required|trim',
                    'label' => 'Moblie No'
                )
            )
        );
        return $ruleConfig[$rule];
    }

    public function dt_ajax_trans_pro_get($uid=null,$where=null){
        $this->datatables->select('t.submitted_date,bt.type,bs.status,t.id as tid',false);
        $this->datatables->edit_column('submitted_date','$1','dateFormatChange(submitted_date)');
        $this->datatables->edit_column('tid','$1','changeLink(type,tid,$uid)');
        $this->datatables->where('t.user_id',$uid);
        $this->datatables->from('bond_transactions as t');
        $this->datatables->join('bond_licence as b','t.id=b.transaction_id','LEFT');
        $this->datatables->join('standard_request as s','t.id=s.transaction_id','LEFT');
        $this->datatables->join('bond_notary_std as n','t.id=n.transaction_id','LEFT');
        $this->datatables->join('bond_type as bt','t.bond_type=bt.id','LEFT');
        $this->datatables->join('bond_status as bs','t.status=bs.id','LEFT');
        return $this->datatables->generate();
    }
    public function updateUser($data = array()){
        $this->db->where('id',$data['id']);
        return $this->db->update('user',$data);
    }
    public function getUserData($data = array()) {
        $this->db->select('*');
        if(isset($data['id']) && $data['id'] != ''){
            $this->db->where('id',$data['id']);
        }
        $this->db->from('user'); 
        return $query = $this->db->get()->result();     
    }
    public function deleteUser($id) {
        $this->db->where('id',$id);
        return $this->db->delete('user');
    }
    /*public function check_unique($value, $params){
        list($table, $field, $id) = explode(".", $params);
        $result = $this->db->where($field, $value)->get($table)->row();
        if($result && $result->id != $id){
            return FALSE;
        }else{
            return TRUE;
        }
    }*/
    public function usersAddRules($rule = 'Add', $id = ''){
        $ruleConfig = array(
            'Add' => array(
                array(
                    'field' => 'first_name',
                    'rules' => 'required|trim',
                    'label' => 'First Name'
                ),
                array(
                    'field' => 'last_name',
                    'rules' => 'required|trim',
                    'label' => 'Last Name'
                ),
                array(
                    'field' => 'company',
                    'rules' => 'required|trim',
                    'label' => 'Company'
                ),
                array(
                    'field' => 'title',
                    'rules' => 'required|trim',
                    'label' => 'Title'
                ),
                array(
                    'field' => 'permission',
                    'rules' => 'required|trim',
                    'label' => 'Permission'
                ),
                array(
                    'field' => 'email',
                    'rules' => 'required|trim|valid_email|is_unique[user.email]',
                    'label' => 'Email',
                    'errors' => array(
                        'is_unique' => '%s address is already being used. Please use another email.',
                    ),
                ),
            ),
            'Edit' => array(
              array(
                    'field' => 'first_name',
                    'rules' => 'required|trim',
                    'label' => 'First Name'
                ),
                array(
                    'field' => 'last_name',
                    'rules' => 'required|trim',
                    'label' => 'Last Name'
                ),
                array(
                    'field' => 'company',
                    'rules' => 'required|trim',
                    'label' => 'Company'
                ),
                array(
                    'field' => 'title',
                    'rules' => 'required|trim',
                    'label' => 'Title'
                ),
                array(
                    'field' => 'permission',
                    'rules' => 'required|trim',
                    'label' => 'Permission'
                ),
                array(
                    'field' => 'email',
                    'rules' => 'required|trim|valid_email|callback_check_unique[user.email.'.$id.']',
                    //'rules' => 'required|trim|valid_email',
                    'label' => 'Email',
                    'errors' => array(
                        'is_unique' => '%s address is already being used. Please use another email.',
                        'check_unique' => '%s address is already being used. Please use another email.',
                    ),
                ),
            )
        );
    return $ruleConfig[$rule];
  }
}
?>