<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Auth_model extends CI_Model { 
	
	function __construct(){
        parent::__construct();		
    }
      // add Table Data details
	public function addTableData($tableName, $data = array()) {
		$this->db->insert($tableName,$data);
		return $this->db->insert_id();
	}
	// Check admin login details
	public function checkAdminLogin($data = array()) {
		$this->db->select('*');
		if(isset($data['email']) && $data['email'] != ''){
			$this->db->where('email',$data['email']);
		}
		if(isset($data['password']) && $data['password'] != ''){
			$this->db->where('password',$data['password']);
		}
		if(isset($data['user_type']) && $data['user_type'] != ''){
			$this->db->where('user_type',$data['user_type']);
		}
		if(isset($data['token']) && $data['token'] != ''){
			$this->db->where('token',$data['token']);
		}
	 	// $where = '(permission_id="1" or permission_id = "4")';
       	// $this->db->where($where);
		$this->db->from('user');	
		return $query = $this->db->get()->row();		
	}

	//Update admin details
	public function updateAdminUser($data){
		if(isset($data['admin_id']) && $data['admin_id'] != ''){
			$this->db->where('admin_id',$data['admin_id']);
		}
		return $this->db->update('user',$data);
	}

	//Update System User details
    public function uploadUserData($data = array()){
        if(isset($data['id']) && $data['id'] != ''){
            $this->db->where('id',$data['id']);
        }
        return $this->db->update('user',$data);
    }

    /*API*/
    /*API*/
	public function checkEmpLoginExistsApi($data = array()) {
        $this->db->select('id, first_name, last_name, company, title, email, user_type, status');
        // $this->db->where('status','1');
        if(isset($data['password']) && $data['password'] != ''){
            $this->db->where('password',$data['password']);
        }
        if(isset($data['email']) && $data['email'] != ''){
            $this->db->where('email',$data['email']);
        }
        if(isset($data['token']) && $data['token'] != ''){
            $this->db->where('token',$data['token']);
        }
        if(isset($data['id']) && $data['id'] != ''){
            $this->db->where('id',$data['id']);
        }
        if(isset($data['user_type']) && $data['user_type'] != ''){
            $this->db->where('user_type',$data['user_type']);
        }
        $this->db->from('user');


        return $query = $this->db->get()->row();
    }
    public function userAddRules($rule = 'add', $id = ''){
    	$ruleConfig = array(
			'Edit' => array(
		        array(
	                'field' => 'first_name',
	                'rules' => 'required|trim',
	                'label' => 'First Name'
		        ),
		        array(
	                'field' => 'last_name',
	                'rules' => 'required|trim',
	                'label' => 'Last Name'
		        ),
		        array(
	                'field' => 'company',
	                'rules' => 'required|trim',
	                'label' => 'Company'
		        ),
		        array(
	                'field' => 'title',
	                'rules' => 'required|trim',
	                'label' => 'Title'
		        ),
		        array(
	                'field' => 'password',
	                'rules' => 'required|trim',
	                'label' => 'Password'
		        ),
		       	array(
	                'field' => 'email',
	                'rules' => 'required|trim|valid_email|is_unique[user.email]',
	                'label' => 'Email',
	                'errors' => array(
	                    'is_unique' => '%s address is already being used. Please use another email.',
	                ),
		        ),
		    )
		);
    	return $ruleConfig[$rule];
    }

}
?>