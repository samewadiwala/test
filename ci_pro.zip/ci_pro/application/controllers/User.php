<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {

	

	public function __construct(){
		parent::__construct();
		$this->load->model('user_model');
		$this->lang->load('message','english');

		error_reporting(0);
	}
	public function index()
	{
		$data['title'] 			= 'User';
		$data['active_class'] 	= 'User';
		$data['inner_class'] 	= 'User';
		$data['extras'] 		= $this->load->view('user/extras', '', true);
		$this->template->load('master','user/index',$data);
	}

	public function user_table(){
		$filter = $this->input->post();
    	echo $this->user_model->dt_ajax_user_get($filter);
    	exit();
    }

    public function add(){
    	$data['title'] 			= 'User';
		$data['active_class'] 	= 'User';
		$data['inner_class'] 	= 'User';
		$data['extras'] = $this->load->view('user/extras', '', true);
		$this->template->load('master','user/add',$data);
		
		if($this->input->is_ajax_request()){
			$this->load->library('form_validation');
			$id 	= null;
			$result = $this->input->post('user');
			$ss  	= $this->form_validation->set_rules($this->user_model->validate());
			if ($this->form_validation->run() == TRUE){
				try{
					$user = array(
						'userName'		=> $result['userName'],
						'password'		=> md5($result['password']),
						'status'		=> '2'
					);

					$id = addtableData('user',$user);

					$userProfile = array(
						'firstName'		=> $result['firstName'],
						'lastName'		=> $result['lastName'],
						'moblieNo'		=> $result['moblieNo'],
						'userId'		=> $id
					);

					$userProfile = addtableData('userProfile',$userProfile);

					if($userProfile){
						$res = [
							'status' 	=> 'success',
							'html' 		=> 'Save',
							'url'		=> base_url().'user'
						];
					}else{
						$res = [
							'status' 	=> 'failure',
							'html' 		=> 'Some thing went worng'
						];
					}
				}catch(Exception $e) {
  					$res = [
							'status' 	=> 'failure',
							'html' 		=> $e->getMessage(),
						];
				}
			}else{
				$res = [
						'status' 	=> 'failure',
						'html' 		=> validation_errors()
					];
			} 
			$this->output_json($res);
		}
    }

    public function edit($id){
    	$data['title'] 			= 'User Edit';
		$data['active_class'] 	= 'User';
		$data['inner_class'] 	= 'User';
		$data['extras'] 		= $this->load->view('user/extras', '', true);
		
		$this->template->load('master','user/add',$data);
		if($this->input->is_ajax_request()){
			$this->load->library('form_validation');
			$id 	= null;
			$result = $this->input->post('user');
			$ss  	= $this->form_validation->set_rules($this->user_model->validate());
			if ($this->form_validation->run() == TRUE){
				try{
					$user = array(
						'userName'		=> $result['userName'],
						'password'		=> md5($result['password']),
						'status'		=> '2'
					);

					$id = addtableData('user',$user);

					$userProfile = array(
						'firstName'		=> $result['firstName'],
						'lastName'		=> $result['lastName'],
						'moblieNo'		=> $result['moblieNo'],
						'userId'		=> $id
					);

					$userProfile = addtableData('userProfile',$userProfile);

					if($userProfile){
						$res = [
							'status' 	=> 'success',
							'html' 		=> 'Save',
							'url'		=> base_url().'user'
						];
					}else{
						$res = [
							'status' 	=> 'failure',
							'html' 		=> 'Some thing went worng'
						];
					}
				}catch(Exception $e) {
  					$res = [
							'status' 	=> 'failure',
							'html' 		=> $e->getMessage(),
						];
				}
			}else{
				$res = [
						'status' 	=> 'failure',
						'html' 		=> validation_errors()
					];
			} 
			$this->output_json($res);
		}
    }

    public function view($value='')
    {
    	echo "string";
    	die;
    }
}
