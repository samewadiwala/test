
$( document ).ready(function() {
	$("#UserForm").validate({
	    rules: {
			'email' : {
				required: true,
				email : true,
				emailadd : true,
			},
			'password' : {
				required : function(){
					if($('.mode').val() == "Add"){
						return true;
					}
					else{
						return false;
					}
				}
			},
			'first_name' : {
				required: true,
			},
			'last_name' : {
				required: true,
			},
			'title' : {
				required: true,
			},
			'company' : {
				required: true,
			},
			'permission' : {
				required : true,
			}
			
	    },
	    messages: {
		    'email': {
		        required: "Please enter Email",
		    },
		    'password' : {
		    	required : "Please enter Password",
		    },
		    'first_name' : {
				required: "Please enter First Name",
			},
			'last_name' : {
				required: "Please enter Last Name",
			},
			'title' : {
				required: "Please enter Title",
			},
			'company' : {
				required: "Please enter Company",
			},
			'permission' : {
				required : "Please select Permission",
			}
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			if(element.attr("name") == 'permission'){
				if(element.hasClass('error')) {
					$(element).next('.select2').find('.select2-selection--single').addClass('error'); 
				}
				if(element.hasClass('valid')) {
					$(element).next('.select2').find('.select2-selection--single').removeClass('error');
				}
			}else{
				error.insertAfter($(element));
			}
			if (element.hasClass('cm_select')) {
            	error.insertAfter(element.next('span'));
        	}else{
				error.insertAfter($(element));
			}
	    },
	   /* submitHandler: function(form) {
	    	$('.loadimg').show();
	      var postdata = $('#UserForm').serialize();
	      $.ajax({
	        url: base_url+'user/adduserdata',
	        type: 'POST',
	        data:  postdata,
	        success: function(data) {
	        	if(data.status == 'success'){
        		 	Command: toastr["success"](data.response);
        		 	window.location = "http://php.rlogical.com/hub/user/userindex";
    		 	 	var table = $('.user_tbl1').DataTable();
      				table.ajax.reload( null, false ); 
	        	}else{
	        		$('.error_div').html(data);
	        	}
	        	$('.loadimg').hide();
	        },
	        error: function(e) {
	        }
	      });
	      return false;
	    },*/
	});
	$.validator.addMethod('emailadd', function (value, element) {
	 	if(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value)){
	 		return true;
	 	}
	 	else{
			return this.optional(element); 		
	 	}
    //return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value) || /^\d{10}$/.test(value);
}, "Please enter a valid email");
});
