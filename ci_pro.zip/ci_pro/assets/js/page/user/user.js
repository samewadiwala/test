;
var userForm = {
	form : null,
	msgTemplate : '<div class="alert alert-{{type}}">' + 
		'{{msg}}' +
	'</div>',
	successmsg 	 : null,
	destinations : null,
	bind 		 : null, 
	setup : function(config) {
		this.form = config.form;
		this.successmsg = config.successmsg;
		this.validate();
	},
	validate :function(){
		var _this = this;
		this.form.validate(
		{
			rules: {
				'user[userName]' : {
					required: true,
				},
				'user[password]' : {
					required: true,
				},
				'user[firstName]' : {
					required: true,
				},
				'user[lastName]' : {
					required: true,
				},
				'user[moblieNo]' : {
					required: true,
				}
		    },
		    messages: {
		    	
				'user[userName]' : {
					required: "Please enter User Name",
				},
				'user[password]' : {
					required: "Please enter password",
				},
				'user[firstName]' : {
					required: "Please enter First Name",
				},
				'user[moblieNo]' : {
					required: "Please enter moblieNo",
				}
			},
		    errorPlacement: function(error, element) { 
				
				if (element.hasClass('cm_select')) {
	            	error.insertAfter(element.next('span'));
	            	return;
	        	}else{
					error.insertAfter($(element));
	            	
					return false;
				}
	    	},
	    	submitHandler: function(form) {
	    		var dis = $(this);
			    $.ajax({
					url : dis.attr('action'),
					type : 'POST',
					dataType : 'JSON',
					data : new FormData(form),
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false, 
					beforeSend : function() {
						$('error.error').html('');					
					},
					success : function(res) {
						switch(res.status) {
							case 'success' :
								jQuery("#success" ).html(res.html);
								jQuery(_this.form)[0].reset();
								window.location.href= res.url;
								break;
							case 'failure' :
								jQuery('#error').html(res.html);
								break;
							default :
								break;
						}
					},
					failure : function(res) {

					},
					complete : function() {
						$('html, body').animate({scrollTop : 0});
					}
				});  
		    }
		})
	},
	table : function() {
		console.log(32);
		var table = $('#usertable').DataTable();
        table.ajax.reload( null, false );
	}


}
;
