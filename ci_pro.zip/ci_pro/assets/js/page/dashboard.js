$( document ).ready(function() {
	$(".cm_select").select2({
		minimumResultsForSearch: -1,		
	});

	$(".toogle_icon").click(function(){		
	    $(".menu_cover").slideToggle();
	});
var typesubmiteddata = $('.typesubmiteddata').val();
    typesubmiteddata = jQuery.parseJSON(typesubmiteddata);
    var categoriesArr = $('.categoriesArr').val();
    categoriesArr = jQuery.parseJSON(categoriesArr);
	// First
	Highcharts.chart('monthlychart', {
	    chart: {
	        type: 'line',
	        backgroundColor: null
	    },
	    title:{
			text: null
		},      
	    credits: {
	        enabled: false
	    },
		legend: { 
			layout: 'vertical',
			align: 'right',			
			verticalAlign: 'top',
			itemMarginBottom: 20,
			itemHoverStyle: {
				color: '#FFFFFF',
			},
			itemStyle: {
				fontSize:'15px',             
				fontWeight: '300',
				color: '#fff',
				fontFamily: 'GothamMedium'				
			},
			labels : {
	            usePointStyle: true
	        }			
		},
	    exporting: {
		    buttons: {		        
		        contextButton: {
		            enabled: false,
		        }    
		    }
		},
		 xAxis: {		 	
		 	labels: {
		 		style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	            },
            	rotation: -45,            	
            },
	        categories: categoriesArr/*['Sep 2017', 'Oct 2017', 'Nov 2017', 'Dec 2017', 'Jan 2018', 'Feb 2018', 'Mar 2018', 'Apr 2018', 'May 2018']*/
	    },
	    yAxis: {  
	    	min:0,
		    title: {
		        text: null
		    },
		    gridLineColor: 'rgba(255, 255, 255, 0.20)',		    
		    labels: {
	            style: {	            	
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	            }
	        }
	    },     
	    plotOptions: {
	      line: { 
	      	dataLabels: {
                enabled: false                
            }
	      }
	    },
	    series: typesubmiteddata/*[{

	        name: 'Abc',
	        lineWidth:3,
	        color:'#01AEEF',
	        data: [1,0,0,0,0,0,0,0,6,0,10]	        
	    }, {
	        name: 'Type2', 
	        color:'#F4B922',
	        lineWidth:3,
	        data: [120, 210, 225, 180, 450, 610, 450, 605, 380]	        
	    }]*/,
	    responsive: {
			rules: [{
			condition: {
			    maxWidth:400	
			},			
			chartOptions: {
				legend: { 
					layout: 'vertical',
					align: 'center',			
					verticalAlign: 'bottom'	,
					itemMarginBottom: 10					
				}
			}
			}]
		}
	});

	// Second
	// Age categories
	var submitedstatusdata = "";
	$.ajax({
		url : base_url + 'dashboard/getbondData',
		type : "POST",
		success: function(data){
			submitedstatusdata = jQuery.parseJSON(data);
		var categories = submitedstatusdata['typearr'];
		var catval = submitedstatusdata['countarr'];
		var typearr = submitedstatusdata['typearr1'];
			Highcharts.chart('bond', {
			    chart: {
			        type: 'bar',
			        backgroundColor: null
			    },
			    title:{
					text: null
				}, 
			    credits: {
			        enabled: false
			    },   
			    xAxis:[{
					categories: categories,
					reversed: true,
					lineWidth: 0,	
					minorGridLineWidth: 0,
					minorTickLength: 0,
		   			tickLength: 0,
					gridLineWidth: 0,		
					labels: {				
					    step: 1,
					    style: {
			                color: '#FFFFFF',
			                fontSize: '12px',
			                fontWeight: '300',
			                fontFamily: 'GothamMedium'
			            }
					}
				}, { // mirror axis on right side
					opposite: true,
					reversed: true,
					categories: catval,
					lineWidth: 0,	
					minorGridLineWidth: 0,
					minorTickLength: 0,
		   			tickLength: 0,
					gridLineWidth: 0,	
					linkedTo: 0,
					labels: {				
					    step: 1,
					    style: {
			                color: '#FFFFFF',
			                fontSize: '12px',
			                fontWeight: '300',
			                fontFamily: 'GothamMedium'
			            }
					}
				}],
			    yAxis:{	    	
			    	lineColor: 'rgba(255, 255, 255, 0.20)',	
			    	gridLineColor: 'rgba(255, 255, 255, 0.20)',	
			    	gridLineWidth: '0',
			    	labels: {
			    		enabled: false,
				 		style: {
			                color: '#FFFFFF',
			                fontSize: '12px',
			                fontWeight: '300',
			                fontFamily: 'GothamMedium'
			           	}        	
		            },	    	
			        title: {
			        	enabled: false
			        }	        
			    },	    
			    legend: {
			        enabled: false
			    },
			    tooltip: {
		            enabled: false
		        },
			    plotOptions: {
			        series: {
			        	pointWidth: 15,	        	
			            borderWidth: 0,
			            dataLabels: {
			                enabled: false,	                             
			                style: {
			                	textOutline: false,
			                	color: '#fff'	                    
			                }
			                //format: '{point.y:.1f}'
			            }
			        }
			    },	    
			    series: [
			        {
			            "name": "Browsers",
			            "colorByPoint": true,
			            "data": typearr
			        }
			    ],    
			});
        },
        error:function() {

        }
	});
	/*var categories = bondcat;
	var catval = ['6', '12', '42', '33', '34'];

	Highcharts.chart('bond', {
	    chart: {
	        type: 'bar',
	        backgroundColor: null
	    },
	    title:{
			text: null
		}, 
	    credits: {
	        enabled: false
	    },   
	    xAxis:[{
			categories: categories,
			reversed: true,
			lineWidth: 0,	
			minorGridLineWidth: 0,
			minorTickLength: 0,
   			tickLength: 0,
			gridLineWidth: 0,		
			labels: {				
			    step: 1,
			    style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	            }
			}
		}, { // mirror axis on right side
			opposite: true,
			reversed: true,
			categories: catval,
			lineWidth: 0,	
			minorGridLineWidth: 0,
			minorTickLength: 0,
   			tickLength: 0,
			gridLineWidth: 0,	
			linkedTo: 0,
			labels: {				
			    step: 1,
			    style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	            }
			}
		}],
	    yAxis:{	    	
	    	lineColor: 'rgba(255, 255, 255, 0.20)',	
	    	gridLineColor: 'rgba(255, 255, 255, 0.20)',	
	    	gridLineWidth: '0',
	    	labels: {
	    		enabled: false,
		 		style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	           	}        	
            },	    	
	        title: {
	        	enabled: false
	        }	        
	    },	    
	    legend: {
	        enabled: false
	    },
	    tooltip: {
            enabled: false
        },
	    plotOptions: {
	        series: {
	        	pointWidth: 15,	        	
	            borderWidth: 0,
	            dataLabels: {
	                enabled: false,	                             
	                style: {
	                	textOutline: false,
	                	color: '#fff'	                    
	                }
	                //format: '{point.y:.1f}'
	            }
	        }
	    },	    
	    series: [
	        {
	            "name": "Browsers",
	            "colorByPoint": true,
	            "data": [
	                {
	                    "name": "Bond 1",
	                    "y": 75,	   
	                    "color": "#01AEEF"
	                },
	                {
	                    "name": "Bond 2",
	                    "y":60,
	                    "color": "#01AEEF"
	                },
	                {
	                    "name": "Bond 3",
	                    "y":35,
	                   	"color": "#01AEEF"
	                },
	                {
	                    "name": "Bond 4",
	                    "y": 38,
	                    "color": "#01AEEF"
	                },
	                {
	                    "name": "Bond 5",
	                    "y": 38,
	                    "color": "#01AEEF"
	                }
	            ]
	        }
	    ],    
	});*/

	// Third
	Highcharts.chart('view', {
	    chart: {
	        type: 'column',
	         backgroundColor: null
	    }, 
	    title:{
			text: null
		},
	    credits: {
	        enabled: false
	    },   
	    xAxis: {
	    	lineColor: 'rgba(255, 255, 255, 0.20)',	
	    	labels: {
		 		style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	           	}        	
            },
	        type: 'category'
	    },
	    yAxis: {
	    	gridLineColor: 'rgba(255, 255, 255, 0.20)',	
	    	labels: {
		 		style: {
	                color: '#FFFFFF',
	                fontSize: '12px',
	                fontWeight: '300',
	                fontFamily: 'GothamMedium'
	           	}        	
            },
	        title: {
	            enabled: false
	        }

	    },
	    legend: {
	        enabled: false
	    },
	    tooltip: {
            enabled: false
        },
	    plotOptions: {
	        series: {
	            borderWidth: 0,
	            dataLabels: {
	                enabled: false,
	                //format: '{point.y:.1f}%'
	            }
	        }
	    },	    
	    series: [
	        {
	            "name": "Browsers",
	            "colorByPoint": true,
	            "data": [
	                {
	                    "name": "18-24",
	                    "y": 12,	   
	                    "color": "#01AEEF"
	                },
	                {
	                    "name": "25-34",
	                    "y":27,
	                    "color": "#F4B922"
	                },
	                {
	                    "name": "35-44",
	                    "y": 17,
	                   	"color": "#01AEEF"
	                },
	                {
	                    "name": "45-54",
	                    "y": 10,
	                    "color": "#F4B922"
	                },
	                {
	                    "name": "55-64",
	                    "y": 12,
	                    "color": "#01AEEF"
	                },
	                {
	                    "name": "65+",
	                    "y": 1.92,
	                    "color": "#F4B922"
	                }
	            ]
	        }
	    ],    
	});
var typeArrData = $('.typeArrData').val();
    typeArrData = jQuery.parseJSON(typeArrData);
	// Fourth
    Highcharts.chart('subbond', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            backgroundColor: null,
            type: 'pie'
        },
        title: {
			style: {
			 	color: '#FFFFFF',
			 	fontSize: '14px',
			 	fontFamily: 'GothamMedium'				
			},
            text: $('#total').val()+'<br>Total',
        	align: 'center',
	        verticalAlign: 'middle',
	        y:-5,
	        x:-95        
        },
        credits: {
            enabled: false,
        },
        plotOptions: {
            pie: {
            	size:'80%',
                center: ["50%", "50%"],
                animation: false,
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {                
                    enabled: false,                    
                },
                showInLegend: true,
                borderWidth: 0
            },
           series: {
              marker: {
                  enabled: true,              
              }
            }
        },
        legend: {
        	itemHoverStyle: {
				color: '#FFFFFF'
			},
        	itemStyle: {
             fontSize:'15px',             
             fontWeight: '300',
             color: '#fff'
          },
            enabled: true,
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            itemMarginBottom: 20,
            color: '#ffffff	'	
        },
        series: [{
        	innerSize: '80%',
            allowPointSelect: true,
            animation: true,
            name: '',
            colorByPoint: true,            
            data: typeArrData,
            marker : {symbol : 'square' }
        }],
        responsive: {
			rules: [{
			condition: {
			    maxWidth:400
			},			
			chartOptions: {
				title: {						           
			        y:-65,
			        x:0        
		        },
				legend: { 
					itemMarginBottom: 10,
					layout: 'vertical',
					align: 'center',			
					verticalAlign: 'bottom'						
				}
			}
			}]
		}        
    });	
    
});