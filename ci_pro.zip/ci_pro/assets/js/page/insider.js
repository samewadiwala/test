$( document ).ready(function() {
	$(".cm_select").select2({
		minimumResultsForSearch: -1,		
	});

	$(".toogle_icon").click(function(){		
	    $(".menu_cover").slideToggle();
	});	

	$('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
        $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
    });

	if($('.marketingres_tbl').length > 0){
		marketingres_tbl = $('.marketingres_tbl').DataTable({
			"responsive": true,
            "processing": false,
            "serverSide": true,
            "bAutoWidth": false,
            "dom": '<"head_cover"<"add_user">>rt<"backPagi"p>',
            "iDisplayLength":-1,
            /*"scrollY": "500px",
            "scrollCollapse": true,*/
            "pageLength": 20,
            "ajax": {
                "url": base_url + "insider/marketing_table",
                "type": "POST"
            },
            columnDefs: [
                { orderable: false, targets: [-1] }
            ],
            oLanguage:  {
       	 		"sSearch": "", 
	            oPaginate: {
	              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
	              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
	           }
          	},
            "initComplete": function(settings, json) {
            }
		});
		 marketingres_tbl.columns().iterator('column', function(ctx, idx){
			$(marketingres_tbl.column(idx).header()).append('<span class="sort-icon"/>');
		});
	}

	$(document).on('click','.statusMarketing',function(){
		var status = $(this).attr('data-status');
		var id = $(this).attr('data-id');
		$.ajax({
			url : base_url+'insider/updateStatus',
			type : "POST",
			data : {'rID' : id, 'status' : status},
			success: function (data){
				var table = $('.marketingres_tbl').DataTable();
				table.ajax.reload(null,false);
			}
		});
	});
	$(document).on('click','.statusBondteam',function(){
		var status = $(this).attr('data-status');
		var id = $(this).attr('data-id');
		$.ajax({
			url : base_url+'insider/updatebondStatus',
			type : "POST",
			data : {'rID' : id, 'status' : status},
			success: function (data){
				var table = $('.bondteam_tbl').DataTable();
				table.ajax.reload(null,false);
			}
		});
	});
	$('.marketingresSearch').on('keyup',function(){
		var table = $('.marketingres_tbl').DataTable();
		table.search(this.value).draw();
	});
	$('.bondteamSearch').on('keyup',function(){
		var table = $('.bondteam_tbl').DataTable();
		table.search(this.value).draw();
	});
	$(document).on('click','.addMarketingres', function(){
			$('.loadimg').show();
			$.ajax({
				url:base_url+"insider/addmarketingpopup/",
				type: "POST",
				data:  {'rID':'rID'},
				success:function(data){
					$('.insiderMaketingDiv').html(data);
					$('#add_marketing_res').modal('show');
					$('.loadimg').hide();
				},
				error:function(){
				}
			});
		});
	$(document).on('click','.addbondteam', function(){
			$('.loadimg').show();
			$.ajax({
				url:base_url+"insider/addbondteampopup/",
				type: "POST",
				data:  {'rID':'rID'},
				success:function(data){
					$('.insiderBondteamDiv').html(data);
					$('#bond_team_detail').modal('show');
					$('.loadimg').hide();
				},
				error:function(){
				}
			});
		});
	
	$(document).on('click','.editMarketing',function(){
			var rID = $(this).attr('data-id');
			$('.loadimg').show();
			$.ajax({
				url:base_url+'insider/editmarketingpopup/',
				type : "POST",
				data : {'rID' : rID },
				success : function(data){
					$('.insiderMaketingDiv').html(data);
					$('#add_marketing_res').modal('show');
					$('.loadimg').hide();
				},
				error : function(){
				}
			});
		});
	$(document).on('click','.editBondteam',function(){
			var rID = $(this).attr('data-id');
			$('.loadimg').show();
			$.ajax({
				url:base_url+'insider/editbondteampopup/',
				type : "POST",
				data : {'rID' : rID },
				success : function(data){
					$('.insiderBondteamDiv').html(data);
					$('#bond_team_detail').modal('show');
					$('.loadimg').hide();
				},
				error : function(){
				}
			});
		});
	$(document).on('click','.deleteMarketing',function(){
    	var rID = $(this).attr('data-id');
    	$('.deleteMarketings').attr('data-id',rID);
    	$('#deleteMarketing').modal('show');
    });
	$(document).on('click','.deleteMarketings',function(){
    	var rID = $(this).attr('data-id');
    	$('#deleteMarketing').modal('hide');
    	$('.loadimg').show();
    	$.ajax({
	            url: base_url+"insider/deleteMarketing",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                if(data.status == 'success'){
	                    Command: toastr["success"](data.response);
	                    var table = $('.marketingres_tbl').DataTable();
      					table.ajax.reload( null, false ); 
	                }else{
	                }
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
    });
    $(document).on('click','.deleteBondteam',function(){
    	var rID = $(this).attr('data-id');
    	$('.deleteBondteams').attr('data-id',rID);
    	$('#deleteBondteam').modal('show');
    });
	$(document).on('click','.deleteBondteams',function(){
    	var rID = $(this).attr('data-id');
    	$('#deleteBondteam').modal('hide');
    	$('.loadimg').show();
    	$.ajax({
	            url: base_url+"insider/deleteBondteam",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                if(data.status == 'success'){
	                    Command: toastr["success"](data.response);
	                    var table = $('.bondteam_tbl').DataTable();
      					table.ajax.reload( null, false ); 
	                }else{
	                }
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
    });
    if($('.bondteam_tbl').length > 0){
		bondteam_tbl = $('.bondteam_tbl').DataTable({
			"responsive": true,
            "processing": false,
            "serverSide": true,
            "bAutoWidth": false,
            "dom": '<"head_cover"<"add_user">>rt<"backPagi"p>',
            "iDisplayLength":-1,
            /*"scrollY": "500px",
            "scrollCollapse": true,*/
            "pageLength": 20,
            "ajax": {
                "url": base_url + "insider/bondteam_table",
                "type": "POST"
            },
            order: [[ 1, 'asc' ]],
            columnDefs: [
                { orderable: false, targets: [-1,0] }
            ],
            oLanguage:  {
       	 		"sSearch": "", 
	            oPaginate: {
	              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
	              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
	           }
          	},
            "initComplete": function(settings, json) {
            }
		});
		 bondteam_tbl.columns().iterator('column', function(ctx, idx){
			$(bondteam_tbl.column(idx).header()).append('<span class="sort-icon"/>');
		});
	}
    
});
$(document).on('change', '.docImage', function(e) {
	console.log();
	$('.uploadeddoc_name').attr('value', e.target.files[0].name);
    });
/*$(document).on('change', '.profileimg', function(e) {
	console.log();
	$('.imageName').attr('value', e.target.files[0].name);
    });*/
    
$(document).on('change', '.profileimg', function() {
        readURLuser(this);
    });
    function readURLuser(input){
        if (input.files && input.files[0]) {
        	var reader = new FileReader();
        	reader.onload = function (e) {
           	$('.bondteamImg').attr('src', e.target.result);
        	}
        reader.readAsDataURL(input.files[0]);
    	}
    }

