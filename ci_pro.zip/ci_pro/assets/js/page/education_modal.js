$( document ).ready(function() {
	$("#FaqForm").validate({
	    rules: {
			'question' : {
				required: true,
			},
			'answer' : {
				required: true,
			},
			
	    },
	    messages: {
		    'question': {
		        required: "Please enter Question",
		    },
		    'answer': {
		        required: "Please enter Answer",
		     },
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			error.insertAfter($(element));
	    },
	    submitHandler: function(form) {
	    	$('.loadimg').show();
	      var postdata = $('#FaqForm').serialize();
	      $.ajax({
	        url: base_url+'education/addfaq',
	        type: 'POST',
	        data:  postdata,
	        success: function(data) {
	        	if(data.status == 'success'){
        		 	Command: toastr["success"](data.response);
	        		$('#add_faq').modal('hide');
    		 	 	var table = $('.faq_tbl').DataTable();
      				table.ajax.reload( null, false ); 
	        	}else{
	        		$('.error_div').html(data);
	        	}
	        	$('.loadimg').hide();
	        },
	        error: function(e) {
	        }
	      });
	      return false;
	    },
	});
	$("#TermsForm").validate({
	    rules: {
			'term' : {
				required: true,
			},
			'description' : {
				required: true,
			},
			
	    },
	    messages: {
		    'term': {
		        required: "Please enter Term",
		    },
		    'description': {
		        required: "Please enter Description",
		     },
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			error.insertAfter($(element));
	    },
	    submitHandler: function(form) {
	    	$('.loadimg').show();
	      var postdata = $('#TermsForm').serialize();
	      $.ajax({
	        url: base_url+'education/addterms',
	        type: 'POST',
	        data:  postdata,
	        success: function(data) {
	        	if(data.status == 'success'){
        		 	Command: toastr["success"](data.response);
	        		$('#add_terms').modal('hide');
    		 	 	var table = $('.terms_tbl').DataTable();
      				table.ajax.reload( null, false ); 
	        	}else{
	        		$('.error_div').html(data);
	        	}
	        	$('.loadimg').hide();
	        },
	        error: function(e) {
	        }
	      });
	      return false;
	    },
	});
	$("#BondForm").validate({
	    rules: {
			'title' : {
				required: true,
			},
			'educationImg[]':{
				required : function(){
					var str = $('.educationImg').attr('src');
					if(str.search("no-image.jpg") >= 0){
                    	return true;
                   	}
                   	else { 
                   	 	return false;
                   	}
				},
				extension: "jpeg|png|tiff|jpg",
				//filesize : "15048",
			},
			'contentFile[]' : {
				required : function(){
					if($('.contentfile').val() != ""){
                    	return false;
                   	}
                   	else { 
                   	 	return true;
                   	}
				},
				extension: "pdf|mp4",
			},
			'post_article' : {
				required : true,
			}
	    },
	    messages: {
		    'title': {
		        required: "Please enter Title",
		    },
		    'educationImg[]':{
				required : "Please select image",
				extension: "Please select only .jpeg,.png and .tiff file",
				//filesize : "Please upload low size photo",
			},
			'contentFile[]' : {
				required : "Please select file",
				extension: "Please select only .pdf and .mp4 file",
			},
			'post_article' : {
				required : "Please enter Post article date",
			}
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			error.insertAfter($(element));
	    },
	    submitHandler: function(form) {
	    	$('.loadimg').show();
	    	var postdata = new FormData( $("#BondForm")[0] );
	    	console.log(postdata);
	      $.ajax({
	        url: base_url+'education/addbond',
	        type: 'POST',
	        data:  postdata,
	        contentType: false,
		    cache: false,
		    processData:false,	
	        success: function(data) {
	        	if(data.status == 'success'){
        		 	Command: toastr["success"](data.response);
	        		$('#add_bond').modal('hide');
    		 	 	var table = $('.bonds_tbl').DataTable();
      				table.ajax.reload( null, false ); 
	        	}else{
	        		$('.error_div').html(data);
	        	}
	        	$('.loadimg').hide();
	        },
	        error: function(e) {
	        }
	      });
	      return false;
	    },
	});
	$('#datetimepicker').datetimepicker({
		//format: 'MM/DD/YYYY H:I'
		//inline: true,
                //sideBySide: true,
}).on("dp.change", function (e) {
        $('#datetimepicker').data('DateTimePicker').hide();
    });
});

/*$(document).on('click','.statusBond',function(){
	var status = $(this).attr('data-status');
	var id = $(this).attr('data-id');
	$.ajax({
		url : base_url+'education/changeBondStatus',
		type : "POST",
		data : {'rID' : id, 'status' : status},
		success : function(data){
			if(data.status == 'success'){
				Command: toastr["success"](data.response);
				var table = $('.bonds_tbl').DataTable();
      			table.ajax.reload( null, false );
      		}else{
      			$('.error_div').html(data);
      		}
		}
	});
});*/


            


