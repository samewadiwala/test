$( document ).ready(function() {
	$(".cm_select").select2({
		minimumResultsForSearch: -1,		
	});

	$(".toogle_icon").click(function(){		
	    $(".menu_cover").slideToggle();
	});	

	$('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
        $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
    });

    /*$('.user_tbl').DataTable({
        "dom": 'rt',
        "iDisplayLength":-1,
        "ordering": false,        
	    "scrollY": "500px",
	    "scrollCollapse": true,
	    "initComplete": function(settings, json) {
	        $('.dataTables_scroll').find('.dataTables_scrollBody').mCustomScrollbar({ theme: 'dark' });
	    }
    });*/

    if($('.user_tbl1').length > 0){
		user_tbl = $('.user_tbl1').DataTable({
			"responsive": true,
            "processing": false,
            "serverSide": true,
            "bAutoWidth": false,
            "dom": '<"head_cover"<"add_user">>rt<"backPagi"p>',
            "iDisplayLength":-1,
            /*"scrollY": "500px",
            "scrollCollapse": true,*/
            "pageLength": 2,
            "ajax": {
                "url": base_url + "user/user_table",
                "type": "POST"
            },
            columnDefs: [
                { orderable: false, targets: [-1] }
            ],
            oLanguage:  {
       	 		"sSearch": "", 
	            oPaginate: {
	              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
	              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
	           }
          	},
            "initComplete": function(settings, json) {
            }
		});
		 user_tbl.columns().iterator('column', function(ctx, idx){
			$(user_tbl.column(idx).header()).append('<span class="sort-icon"/>');
		});
	}
	$('.userSearch').on('keyup',function(){
		var table = $('.user_tbl1').DataTable();
		table.search(this.value).draw();
	});
   $('.statusSearch').on('change',function(){
        var table = $('.user_tbl1').DataTable();
        console.log(this.value);
        table.column(3).search(this.value).draw();
    });
    
});