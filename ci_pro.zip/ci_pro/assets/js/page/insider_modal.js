$( document ).ready(function() {
    $("#MarketingresForm").validate({
        rules: {
            'doc_name' : {
                required: true,
            },
            'marketingres[]':{
                required : function(){
                   if($('.uploadeddoc_name').val() != ""){
                    return false;
                   }
                   else { 
                    return true;
                   } 
                }
            },
            'search_keyword' : {
                required : true,
            }
        },
        messages: {
            'doc_name': {
                required: "Please enter Document Name",
            },
            'marketingres[]':{
                required: "Please Upload File",
            },
            'search_keyword':{
                required : true,
            }
        },
        // errorElement : 'div',
        errorPlacement: function(error, element) { 
            error.insertAfter($(element));
        },
        submitHandler: function(form) {
            $('.loadimg').show();
            var postdata = new FormData( $("#MarketingresForm")[0] );
            console.log(postdata);
          $.ajax({
            url: base_url+'insider/addmarketingres/',
            type: 'POST',
            data:  postdata,
            contentType: false,
            cache: false,
            processData:false,  
            success: function(data) {
                if(data.status == 'success'){
                    Command: toastr["success"](data.response);
                    $('#add_marketing_res').modal('hide');
                    var table = $('.marketingres_tbl').DataTable();
                    table.ajax.reload( null, false ); 
                }else{
                    $('.error_div').html(data);
                }
                $('.loadimg').hide();
            },
            error: function(e) {
            }
          });
          return false;
        },
    });
    $("#bondteamForm").validate({
        rules: {
            'first_name' : {
                required: true,
            },
            'last_name' : {
                required: true,
            },
            'bio' : {
                required : true,
            },
            'profileimg[]' :{
                required : function(){
                    var str = $('.bondteamImg').attr('src');
                    if(str.search("no-image.jpg") >= 0){
                        return true;
                    }else{
                        return false;
                    }
                },
            },
            'email' : {
                required: true,
                email: true,
            },
            'phone_number' : {
                required: true,
                customphone : true,
            },
        },
        messages: {
            'first_name': {
                required: "Please enter First Name",
            },
            'last_name': {
                required: "Please enter Last Name",
            },
            'bio' : {
                required : "Please enter Bio",
            },
            'profileimg[]' :{
                required : "Please Upload Image",
            },
            'email': {
                required: "Please enter Email",
            },
            'phone_number': {
                required: "Please enter Phone Number",
            },
        },
        // errorElement : 'div',
        errorPlacement: function(error, element) { 
            error.insertAfter($(element));
        },
        submitHandler: function(form) {
            $('.loadimg').show();
            var postdata = new FormData( $("#bondteamForm")[0] );
            console.log(postdata);
          $.ajax({
            url: base_url+'insider/addbondteam/',
            type: 'POST',
            data:  postdata,
            contentType: false,
            cache: false,
            processData:false,  
            success: function(data) {
                if(data.status == 'success'){
                    Command: toastr["success"](data.response);
                    $('#bond_team_detail').modal('hide');
                    var table = $('.bondteam_tbl').DataTable();
                    table.ajax.reload( null, false ); 
                }else{
                    $('.error_div').html(data);
                }
                $('.loadimg').hide();
            },
            error: function(e) {
            }
          });
          return false;
        },
    });
    $.validator.addMethod('customphone', function (value, element) {
        if(/^\(\d{3}\)\d{3}[\-]\d{4}$/.test(value)){
            return true;
        }/*else if(/^\d{10}$/.test(value)){
            return true;
        }*/
        else{
            return this.optional(element);      
        }
    //return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value) || /^\d{10}$/.test(value);
}, "Please enter a valid phone number");
});


            


