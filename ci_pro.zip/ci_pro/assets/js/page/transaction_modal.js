
$( document ).ready(function() {
	$("#licencepermitForm").validate({
	    rules: {
	    	'submitted' : {
				required: true,
			},
			'request_from' : {
				required: true,
			},
			'company' : {
				required: true,
			},
			'company_address' : {
				required: true,
			},
			'company_city' : {
				required: true,
			},
			'company_state' : {
				required: true,
			},
			'company_zip' : {
				required: true,
				//numeric : true,
				customzip : true,
			},
			'municipality_name' : {
				
				required : true,
			},
			'municipality_address' : {
				
				required : true,
			},
			'municipality_city' : {
				
				required : true,
			},
			'municipality_state' : {
				
				required : true,
			},
			'municipality_zip' : {
				
				required : true,
				customzip : true,
			},
			'amount' : {
				required: true,
			},
			'decription_of_work' : {
				required: true,
			},
			'description' : {
				required: true,
			},
			/*'bond_number' : {
				required: true,
			},
			'permitImg[]' : {
				required : function(){
					//if($('.mode').val()=="Edit" && $('.uploadeddoc_name').val()!= ""){
						if($('.mode').val()=="Edit" && $('.uploadeddoc_name').val()!= ""){
						return false;
					}else{
						return true;
					}
				},
				extension: "pdf",
			},
			'pricing_notes' : {
				required: true,
			},*/
	    },
	    messages: {
	    	'submitted' : {
				required: "Please enter Submitted Date",
			},
			'request_from' : {
				required: "Please enter Request From",
			},
		    'company' : {
				required: "Please enter Company Name",
			},
			'company_address' : {
				required: "Please enter Company Address",
			},
			'company_city' : {
				required: "Please enter Company City",
			},
			'company_state' : {
				required: "Please enter Company state",
			},
			'company_zip' : {
				required: "Please enter Company zip",
				customzip : "Please enter Valid Zip",
			},
			'municipality_name' : {
				required: "Please enter Municipality Name",
			},
			'municipality_address' : {
				required: "Please enter Municipality Address",
			},
			'municipality_city' : {
				required: "Please enter Municipality City",
			},
			'municipality_state' : {
				required: "Please enter Municipality State",
			},
			'municipality_zip' : {
				required: "Please enter Municipality zip",
				numeric : "Please enter Number Only",
			},
			'amount' : {
				required: "Please enter Amount",
			},
			'decription_of_work' : {
				required: "Please enter Description of work",
			},
			'description' : {
				required: "Please enter Other description",
			},
			/*'bond_number' : {
				required: "Please enter Bond Number",
			},
			'permitImg[]' : {
				required : "Please select File",
				extension: "Please select only .pdf",
			},
			'pricing_notes' : {
				required: "Please enter Pricing Notes",
			},*/
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			if(element.attr("name") == 'company_state' || element.attr("name") == 'municipality_state' || element.attr('name')=='decription_of_work'){
				if(element.hasClass('error')) {
					$(element).next('.select2').find('.select2-selection--single').addClass('error'); 
				}
				if(element.hasClass('valid')) {
					$(element).next('.select2').find('.select2-selection--single').removeClass('error');
				}
			}else{
				error.insertAfter($(element));
			}
			if (element.hasClass('cm_select')) {
            	error.insertAfter(element.next('span'));
        	}else{
				error.insertAfter($(element));
			}
	    },
	    
	});
	$("#standardrequestForm").validate({
	    rules: {
	    	'bondData[submitted_date]' : {
				required: true,
			},
			'bondData[request_from]' : {
				required: true,
			},
			'standardrequestData[principle_name]' : {
				required: true,
			},
			'standardrequestData[principle_address]' : {
				required: true,
			},
			'standardrequestData[principle_city]' : {
				required: true,
			},
			'standardrequestData[principle_state]' : {
				required: true,
			},
			'standardrequestData[principle_zip]' : {
				required: true,
				customzip : true,
			},
			'standardrequestData[obligee_name]' : {
				required: true,
			},
			'standardrequestData[obligee_address]' : {
				required: true,
			},
			'standardrequestData[obligee_city]' : {
				required: true,
			},
			'standardrequestData[obligee_state]' : {
				required: true,
			},
			'standardrequestData[obligee_zip]' : {
				required: true,
				customzip : true,
			},
			'standardrequestData[type_bond]' : {
				required: true,
			},
			'standardrequestData[year]' : {
				required: true,
			},
			'standardrequestData[description]' : {
				required: true,
			},
			'standardrequestData[amount]' : {
				required: true,
			},
			'standardrequestData[improvement_cost]' : {
				required: true,
			},
			'standardrequestData[improvement_date]' : {
				required: true,
			},
			'standardrequestData[need_date]' : {
				required: true,
			},
			'standardrequestData[particular_bond_req]' : {
				required: true,
			},
			'standardrequestData[preferred_delivery]' : {
				required: true,
			},
			'standardrequestData[remark]' : {
				required: true,
			},
			'standardrequestData[phone]' : {
				required: true,
			},
			/*'bondData[bond_number]' : {
				required: true,
			},
			'bondData[pricing_notes]' : {
				required: true,
			},
			'bondFile[]':{
				required : function(){
					if($('.mode').val()=="Edit" && $('.docname').val()!= ""){
						return false;
					}else{
						return true;
					}
				},
				extension: "pdf|doc",
			}*/
	    },
	    messages: {
	    	'bondData[submitted_date]' : {
				required: "Please enter Submitted Date",
			},
			'bondData[request_from]' : {
				required: "Please enter Request From",
			},
			'standardrequestData[principle_name]' : {
				required: "Please enter Principle Name",
			},
			'standardrequestData[principle_address]' : {
				required: "Please enter Principle Address",
			},
			'standardrequestData[principle_city]' : {
				required: "Please enter Principle City",
			},
			'standardrequestData[principle_state]' : {
				required: "Please enter Principle State",
			},
			'standardrequestData[principle_zip]' : {
				required: "Please enter Principle Zip",
				numeric : "Please enter Number Only",
			},
			'standardrequestData[obligee_name]' : {
				required: "Please enter Obligee Name",
			},
			'standardrequestData[obligee_address]' : {
				required: "Please enter Obligee Address",
			},
			'standardrequestData[obligee_city]' : {
				required: "Please enter Obligee City",
			},
			'standardrequestData[obligee_state]' : {
				required: "Please enter Obligee State",
			},
			'standardrequestData[obligee_zip]' : {
				required: "Please enter Obligee Zip",
				numeric : "Please enter Number Only",
			},
			'standardrequestData[type_bond]' : {
				required: "Please enter Bond Type",
			},
			'standardrequestData[year]' : {
				required: "Please enter Year",
			},
			'standardrequestData[description]' : {
				required: "Please enter Discription",
			},
			'standardrequestData[amount]' : {
				required: "Please enter Amount",
			},
			'standardrequestData[improvement_cost]' : {
				required: "Please enter Improvement Cost",
			},
			'standardrequestData[improvement_date]' : {
				required: "Please enter Improvement Date",
			},
			'standardrequestData[need_date]' : {
				required: "Please enter Need Date",
			},
			'standardrequestData[particular_bond_req]' : {
				required: "Please enter Particular Bond Request",
			},
			'standardrequestData[preferred_delivery]' : {
				required: "Please enter Preferred Delivery",
			},
			'standardrequestData[remark]' : {
				required: "Please enter Remark",
			},
			'standardrequestData[phone]' : {
				required: "Please enter Phone",
			},
			/*'bondData[bond_number]' : {
				required: "Please enter Bond Number",
			},
			'bondData[pricing_notes]' : {
				required: "Please enter Pricing Notes",
			},
			'bondFile[]':{
				required : "Please select File",
				extension: "Please select only .pdf",
			}*/
		},
	    // errorElement : 'div',
	    errorPlacement: function(error, element) { 
			if(element.attr("name") == 'standardrequestData[principle_state]' || element.attr("name") == 'standardrequestData[obligee_state]' || element.attr('name')=='standardrequestData[type_bond]'){
				if(element.hasClass('error')) {
					$(element).next('.select2').find('.select2-selection--single').addClass('error'); 
				}
				if(element.hasClass('valid')) {
					$(element).next('.select2').find('.select2-selection--single').removeClass('error');
				}
			}else{
				error.insertAfter($(element));
			}
			if (element.hasClass('cm_select')) {
            	error.insertAfter(element.next('span'));
        	}else{
				error.insertAfter($(element));
			}
	    },
	    
	});
	 /*$("input.transactionImage").each(function(){
       $(this).rules("add", {
           required:true, 
       });                    
 });*/
 	$('#notaryrequeststdForm').validate({
 		rules : {
 			'bondData[submitted_date]' : {
 				required : true,
 			},
 			'bondData[request_from]' : {
				required: true,
			},
			'notarystdData[notarystd_fullnameofpublic]' : {
				required : true,
			},
			'notarystdData[first_name]' : {
				required : true,
			},
			'notarystdData[last_name]' : {
				required : true,
			},
			'notarystdData[notarystd_street_address]' : {
				required : true,
			},
			'notarystdData[notarystd_city]' : {
				required : true,
			},
			'notarystdData[notarystd_state]' : {
				required : true,
			},
			'notarystdData[notarystd_zip]' : {
				required : true,
				customzip : true,
			},
			'notarystdData[notarystd_residencecounty]' : {
				required : true,
			},
			'notarystdData[notarystd_homephone]' : {
				required : true,
			},
			'notarystdData[notarystd_business_name]' : {
				
				required : true,
			},
			'notarystdData[notarystd_business_address]' : {
				
				required : true,
			},
			'notarystdData[notarystd_business_city]' : {
				
				required : true,
			},
			'notarystdData[notarystd_business_state]' : {
				
				required : true,
			},
			'notarystdData[notarystd_business_zip]' : {
				
				required : true,
				customzip : true,
			},
			'notarystdData[notarystd_business_phone]':{
				
				required : true,
			},
			'notarystdData[notarystd_otheremail]':{
				emailadd : true,
				required : false,
			},
			'notarystdData[notarystd_commission]' : {
				required : true,
			},
			/*'bondData[bond_number]' : {
				required : true,
			},*/
			'notarystdData[notarystd_expiration_date]' : {
				required : true,
			},
			'notarystdData[notarystd_commision_number]' : {
				required : true,
			},
			/*'bondFile[]' : {
				required : function(){
					if($('.mode').val() == "Edit" && $('.bondfilename').val()!= ""){
						return false;
					}else{
						return true;
					}
				},
				extension: "pdf",
			},
			'bondData[pricing_notes]' : {
				required : true,
			},*/
 		},
 		messages: {
 			'bondData[submitted_date]' : {
 				required : "Please enter Submitted Date",
 			},
 			'bondData[request_from]' : {
				required: "Please enter request From",
			},
			'notarystdData[notarystd_fullnameofpublic]' : {
				required : "Please enter Full Name of Public",
			},
			'notarystdData[first_name]' : {
				required : "Please enter First Name",
			},
			'notarystdData[last_name]' : {
				required : "Please enter Last Name",
			},
			'notarystdData[notarystd_street_address]' : {
				required : "Please enter Address",
			},
			'notarystdData[notarystd_city]' : {
				required : "Please enter City",
			},
			'notarystdData[notarystd_state]' : {
				required : "Please enter State",
			},
			'notarystdData[notarystd_zip]' : {
				required : "Please enter Zip",
			},
			'notarystdData[notarystd_residencecounty]' : {
				required : "Please enter Residence County",
			},
			'notarystdData[notarystd_homephone]' : {
				required : "Please Enter Home Phone",
			},
			'notarystdData[notarystd_business_name]' : {
				required : "Please enter Business Name",
			},
			'notarystdData[notarystd_business_address]' : {
				required : "Please enter Business Address",
			},
			'notarystdData[notarystd_business_city]' : {
				required : "Please ente Business City",
			},
			'notarystdData[notarystd_business_state]' : {
				required : "Please enter Business State",
			},
			'notarystdData[notarystd_business_zip]' : {
				required : "Please enter Business Zip",
			},
			'notarystdData[notarystd_business_phone]':{
				required : "Please enter Business Phone",
			},
			'notarystdData[notarystd_commission]' : {
				required : "Please enter Commission Renewal",
			},
			/*'bondData[bond_number]' : {
				required : "Please enter Bond Number",
			},*/
			'notarystdData[notarystd_expiration_date]' : {
				required : "Please enter Expiration Date",
			},
			'notarystdData[notarystd_commision_number]' : {
				required : "Please ente Commission Number",
			},
			/*'bondFile[]' : {
				required : "Please select File",
				extension: "Please select only .pdf",
			},
			'bondData[pricing_notes]' : {
				required : "Please enter Pricing Notes",
			},*/
 		},
 		errorPlacement: function(error, element) { 
			if(element.attr("name") == 'notarystdData[notarystd_business_state]' || element.attr("name") == 'notarystdData[notarystd_state]'){
				if(element.hasClass('error')) {
					$(element).next('.select2').find('.select2-selection--single').addClass('error'); 
				}
				if(element.hasClass('valid')) {
					$(element).next('.select2').find('.select2-selection--single').removeClass('error');
				}
			}else{
				error.insertAfter($(element));
			}
			if (element.hasClass('cm_select')) {
            	error.insertAfter(element.next('span'));
        	}else{
				error.insertAfter($(element));
			}
	    },
 	});
	 $.validator.addMethod('customphone', function (value, element) {
	 	if(/^\(\d{3}\)\d{3}[\-]\d{4}$/.test(value)){
	 		return true;
	 	}/*else if(/^\d{10}$/.test(value)){
	 		return true;
	 	}*/
	 	else{
			return this.optional(element); 		
	 	}
    //return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value) || /^\d{10}$/.test(value);
}, "Please enter a valid phone number");
	  $.validator.addMethod('customzip', function (value, element) {
	 	if(/^\d{5}$/.test(value)){
	 		return true;
	 	}
	 	else{
			return this.optional(element); 		
	 	}
    //return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value) || /^\d{10}$/.test(value);
}, "Please enter a valid zip code");
$.validator.addMethod('emailadd', function (value, element) {
	 	if(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value)){
	 		return true;
	 	}
	 	else{
			return this.optional(element); 		
	 	}
    //return this.optional(element) || /^\d{3}-\d{3}-\d{4}$/.test(value) || /^\d{10}$/.test(value);
}, "Please enter a valid email");	  
});
