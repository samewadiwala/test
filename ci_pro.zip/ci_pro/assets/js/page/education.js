$( document ).ready(function() {
	$(".cm_select").select2({
		minimumResultsForSearch: -1,		
	});

	$(".toogle_icon").click(function(){		
	    $(".menu_cover").slideToggle();
	});	

    $('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
        $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
    });
    var hash = window.location.hash;
	if(hash == "#terms"){
		$('.nav-tabs li:eq(1) a').tab('show'); 
	}
	if(hash == "#faq"){
		$('.nav-tabs li:eq(2) a').tab('show'); 
	}
    if ($('.faq_tbl').length > 0) {
        faq_tbl = $('.faq_tbl').DataTable({
            "responsive": true,
            "processing": false,
            "serverSide": true,
            "bAutoWidth": false,
            "dom": 'rt<"backPagi"p>',
            // "dom": '<"head_cover"f<"add_user">>rt',
            "iDisplayLength":-1,
            /*"scrollY": "500px",
            "scrollCollapse": true,*/
            "pageLength": 20,
            // "order": [[5, 'DESC']],
            "ajax": {
                "url": base_url + "education/faq_table",
                "type": "POST"
            },
            columnDefs: [
                { orderable: false, targets: [-1] }
            ],
           /* oLanguage:  {
                "sSearch": "", //search
            },*/
            oLanguage:  {
       	 		"sSearch": "", 
	            oPaginate: {
	              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
	              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
	           }
          	},
            "initComplete": function(settings, json) {
                // $('.dataTables_scroll').find('.dataTables_scrollBody').mCustomScrollbar({ theme: 'dark' });
            }

        });

        faq_tbl.columns().iterator('column', function(ctx, idx) {
            $(faq_tbl.column(idx).header()).append('<span class="sort-icon"/>');
        });
    }
    /*FAQ Start*/
    	$(document).on('click', '.faqBtn', function() {
	    	// var rID = $(this).attr('data-id');
			$('.loadimg').show();
			$.ajax({
		        url: base_url+"education/addfaqpop/",
		        type: "POST",
		        data:  {'rID':'rID'},
		        success: function(data){
		        	$('.faqModalDiv').html(data);
	        	 	$('#add_faq').modal('show');
	        	 	$('.loadimg').hide();
		        },
		        error: function(){
		        }
	      	});
	    });

	    $(document).on('click', '.editFaq', function() {
	        var rID = $(this).attr('data-id');
	        $('.loadimg').show();
	        $.ajax({
	            url: base_url+"education/editfaqpop",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                $('.faqModalDiv').html(data);
	                $('#add_faq').modal('show');
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
	    });
	    $(document).on('click', '.deleteFaq', function() {
	        var rID = $(this).attr('data-id');
	        $('.deleFaq').attr('data-id',rID);
	        $('#forgot_popup').modal('show');
	    });
	    $(document).on('click', '.deleFaq', function() {
	        var rID = $(this).attr('data-id');
	        $('#forgot_popup').modal('hide');
	        $('.loadimg').show();
	        $.ajax({
	            url: base_url+"education/deletefaq",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                if(data.status == 'success'){
	                    Command: toastr["success"](data.response);
	                    var table = $('.faq_tbl').DataTable();
      					table.ajax.reload( null, false ); 
	                }else{
	                }
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
	    });
	    $('.faqSearch').on( 'keyup', function () {
	    	var table = $('.faq_tbl').DataTable();
		    table.search( this.value ).draw();
		} );
    /*FAQ END*/
    /*TERMS LIBRARY START*/
    	if($('.terms_tbl').length > 0){
    		terms_tbl = $('.terms_tbl').DataTable({
    			"responsive": true,
            	"processing": false,
            	"serverSide": true,
            	"bAutoWidth": false,
            	"dom": 'rt<"backPagi"p>',
            	"iDisplayLength":-1,
            	/*"scrollY": "500px",
            	"scrollCollapse": true,*/
            	"pageLength": 20,
    			"ajax":{
    				"url":base_url + "education/terms_table",
    				"type" : "POST"
    			},
    			columnDefs: [
                	{ orderable: false, targets: [-1] }
            	],
	            oLanguage:  {
	       	 		"sSearch": "", 
		            oPaginate: {
		              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
		              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
		           }
	          	},
	            "initComplete": function(settings, json) {
	            }
    		});
    		terms_tbl.columns().iterator('column',function(ctx,idx){
    			$(terms_tbl.column(idx).header()).append('<span class="sort-icon"/>');
    		});
    	}
    	$('.termsSearch').on('keyup',function(){
			var table = $('.terms_tbl').DataTable();
			table.search(this.value).draw();
		});

		//ADD TERMS
		$(document).on('click','.termsBtn', function(){
			$('.loadimg').show();
			$.ajax({
				url:base_url+"education/addtermspopup/",
				type: "POST",
				data:  {'rID':'rID'},
				success:function(data){
					$('.termsModelDiv').html(data);
					$('#add_terms').modal('show');
					$('.loadimg').hide();
				},
				error:function(){
				}
			});
		});
		// EDIT TERMS
		$(document).on('click','.editTerms',function(){
			var rID = $(this).attr('data-id');
			$('.loadimg').show();
			$.ajax({
				url:base_url+'education/edittermspopup/',
				type : "POST",
				data : {'rID' : rID },
				success : function(data){
					$('.termsModelDiv').html(data);
					$('#add_terms').modal('show');
					$('.loadimg').hide();
				},
				error : function(){

				}
			});
		});
		// DELETE TERMS
		$(document).on('click','.deleteTerms',function(){
			var rID = $(this).attr('data-id');
	        $('.deleteTerm').attr('data-id',rID);
	        $('#deleteTerm').modal('show');
		});
		$(document).on('click', '.deleteTerm', function() {
	        var rID = $(this).attr('data-id');
	        $('#deleteTerm').modal('hide');
	        $('.loadimg').show();
	        $.ajax({
	            url: base_url+"education/deleteterm",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                if(data.status == 'success'){
	                    Command: toastr["success"](data.response);
	                    var table = $('.terms_tbl').DataTable();
      					table.ajax.reload( null, false ); 
	                }else{
	                }
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
	    });
    /*TERMS LIBRARY END*/
    /*BONDS 101 START*/
    if($('.bonds_tbl').length>0){
	    bonds_tbl = $('.bonds_tbl').DataTable({
	    	"responsive" : true,
	    	"processing" : false,
	    	"serverSide" : true,
	    	"bAutoWidth" : false,
	    	"dom" : 'rt<"backPagi"p>',
	    	"iDisplayLength" : -1,
	    	/*"scrollY" : "500px",
	    	"scrollCollapse" : true,*/
	    	"pageLength" : 20,
	    	"ajax" : {
	    		"url" : base_url + 'education/bond_table',
	    		"type" : "POST"
	    	},
	    	columnDefs : [
	    	{ orderable : false, targets : [-1]}
	    	],
	    	oLanguage:  {
       	 		"sSearch": "", 
	            oPaginate: {
	              sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
	              sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
	           }
          	},
	    	"initComplete": function(settings, json){

	    	}
	    });
		bonds_tbl.columns().iterator('column', function(ctx, idx){
			$(bonds_tbl.column(idx).header()).append('<span class="sort-icon"/>');
		});
	}
	$('.bondSearch').on('keyup',function(){
		var table = $('.bonds_tbl').DataTable();
		table.search(this.value).draw();
	});
    $(document).on('change', '.imgInpuser', function() {
        readURLuser(this);
    });
    function readURLuser(input){
        if (input.files && input.files[0]) {
        	var reader = new FileReader();
        	reader.onload = function (e) {
           	$('.educationImg').attr('src', e.target.result);
        	}
        reader.readAsDataURL(input.files[0]);
    	}
    }
    $(document).on('click','.deleteBonds',function(){
    	var rID = $(this).attr('data-id');
    	$('.deleteBond').attr('data-id',rID);
    	$('#deleteBond').modal('show');
    });
    $(document).on('click','.deleteBond',function(){
    	var rID = $(this).attr('data-id');
    	$('#deleteBond').modal('hide');
    	$('.loadimg').show();
    	$.ajax({
	            url: base_url+"education/deletebond",
	            type: "POST",
	            data:  {'rID':rID},
	            success: function(data){
	                if(data.status == 'success'){
	                    Command: toastr["success"](data.response);
	                    var table = $('.bonds_tbl').DataTable();
      					table.ajax.reload( null, false ); 
	                }else{
	                }
	                $('.loadimg').hide();
	            },
	            error: function(){
	            }
	        });
    });
    $(document).on('click','.bondsbtn',function(){
    	$('.loadimg').show();
    	$.ajax({
    		url : base_url+'education/addbondpopup/',
    		type : "POST",
    		data:  {'rID':'rID'},
    		success : function(data){
    			$('.bondModalDiv').html(data);
    			$('#add_bond').modal('show');
    			$('.loadimg').hide();
    		},
    		error : function(){

    		}
    	});
    });
    $(document).on('click','.editBond',function(){
			var rID = $(this).attr('data-id');
			$('.loadimg').show();
			$.ajax({
				url:base_url+'education/editbondpopup/',
				type : "POST",
				data : {'rID' : rID },
				success : function(data){
					$('.bondModalDiv').html(data);
					$('#add_bond').modal('show');
					$('.loadimg').hide();
				},
				error : function(){

				}
			});
		});
    $(document).on('click','.statusBond',function(){
	var status = $(this).attr('data-status');
	var id = $(this).attr('data-id');
	$.ajax({
		url : base_url+'education/changeBondStatus',
		type : "POST",
		data : {'rID' : id, 'status' : status},
		success : function(data){
			if(data.status == 'success'){
				Command: toastr["success"](data.response);
				var table = $('.bonds_tbl').DataTable();
      			table.ajax.reload( null, false );
      		}else{
      			$('.error_div').html(data);
      		}
		}
	});
});
    $(document).on('change', '.docImage', function(e) {
	console.log();
	$('.uploadeddoc_name').attr('value', e.target.files[0].name);
    });
    /*BONDS 101 END*/
});

