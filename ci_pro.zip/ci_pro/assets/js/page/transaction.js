$( document ).ready(function() {
	$(".cm_select").select2({
		minimumResultsForSearch: -1,		
	});

	$(".toogle_icon").click(function(){		
	    $(".menu_cover").slideToggle();
	});	
	
	/*$('.trans_tbl').DataTable({
        "dom": 'rt',
        "iDisplayLength":-1,
        "ordering": false,        
	    "scrollY": "500px",
	    "scrollCollapse": true,
	    "initComplete": function(settings, json) {
	        $('.dataTables_scroll').find('.dataTables_scrollBody').mCustomScrollbar({ theme: 'dark' });
	    }
    });*/
    $('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
        $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
    });
   /* if($('.same_as_company').is(':checked')){
    		$('#municipality_name').attr('value',document.getElementById('company').value);
    		$('#municipality_address').attr('value',document.getElementById('company_address').value);
    		$('#municipality_city').attr('value',document.getElementById('company_city').value);
    		$('#municipality_zip').attr('value',document.getElementById('company_zip').value);
    	}*/
    $('.same_as_company').on('click',function(){
    	if($(this).is(':checked')){
    		$(this).attr('value',1);
    		$('#municipality_name').val($('#company').val());
            if($('#municipality_name').val() != ""){
                $('#municipality_name').removeClass('error');
                $('#municipality_name-error').remove();    
            }
    		$('#municipality_address').val($('#company_address').val());
            if($('#municipality_address').val() != ""){
                $('#municipality_address').removeClass('error');
                $('#municipality_address-error').remove();
            }
    		$('#municipality_city').val($('#company_city').val());
            if($('#municipality_city').val() != ""){
                $('#municipality_city').removeClass('error');
                $('#municipality_city-error').remove();  
            }
            $('#municipality_state').val($('#company_state').val());
            $('#municipality_state').trigger('change');
            if($('#municipality_state').val() != ""){
                $('#municipality_state').removeClass('error');
                $('#municipality_state-error').remove();
            }
    		$('#municipality_zip').val($('#company_zip').val());
            if($('#municipality_zip').val() != ""){
                $('#municipality_zip').removeClass('error');
                $('#municipality_zip-error').remove();  
            }
            
    	}else{
    		$(this).attr('value',0);
    		$('#municipality_name').val("");
    		$('#municipality_address').val("");
    		$('#municipality_city').val("");
    		$('#municipality_state').val("");
    		$('#municipality_zip').val("");
    	}	
    });
    /*if($('.sameaspersonal').is(':checked')){
            $('#businessname').attr('value',document.getElementById('first_name').value);
            $('#businessaddress').attr('value',document.getElementById('personaddress').value);
            $('#businesscity').attr('value',document.getElementById('personcity').value);
            $('#businessstates').attr('value',document.getElementById('personalstates').value);
            $('#businesszip').attr('value',document.getElementById('personzip').value);
            $('#businessphone').attr('value',document.getElementById('personphone').value);
        }*/
    $('.sameaspersonal').on('click',function(){
        if($(this).is(':checked')){
            $(this).attr('value',1);
            $('#businessname').val($('#first_name').val());
            if($('#businessname').val() != ""){
                $('#businessname').removeClass('error');
                $('#businessname-error').remove();
            }
            $('#businessaddress').val($('#personaddress').val());
            if($('#businessaddress').val() != ""){
                $('#businessaddress').removeClass('error');
                $('#businessaddress-error').remove();
            }
            $('#businesscity').val($('#personcity').val());
            if($('#businesscity').val() != ""){
                $('#businesscity').removeClass('error');
                $('#businesscity-error').remove();
            }
            $('#businessstates').val($('#personalstates').val());
            $('#businessstates').trigger('change');
            if($('#businessstates').val() != ""){
                $('#businessstates').removeClass('error');
                $('#businessstates-error').remove();
            }
            
            $('#businesszip').val($('#personzip').val());
            if($('#businesszip').val() != ""){
                $('#businesszip').removeClass('error');
                $('#businesszip-error').remove();
            }
            $('#businessphone').val($('#personphone').val());
            if($('#businessphone').val() != ""){
                $('#businessphone').removeClass('error');
                $('#businessphone-error').remove();
            }
            
        }else{
            $(this).attr('value',0);
            $('#businessname').val("");
            $('#businessaddress').val("");
            $('#businesscity').val("");
            $('#businessstates').val("");
            $('#businesszip').val("");
            $('#businessphone').val("");
        }   
    });
    
    $('#datetimepicker').datetimepicker({
    }).on("dp.change", function (e) {
        $('#datetimepicker').data('DateTimePicker').hide();
    });
    /*$("#datetimepicker").on("dp.change", function (e) {
        $('#datetimepicker').data('DateTimePicker').hide();
    });*/
    $('#datetimepicker1').datetimepicker({
    }).on("dp.change", function (e) {
        $('#datetimepicker1').data('DateTimePicker').hide();
    });
    $('#datetimepicker2').datetimepicker({
    }).on("dp.change", function (e) {
        $('#datetimepicker2').data('DateTimePicker').hide();
    });

    
    if($(".personstate option:selected").val() == "IL"){
            $(".il_required").show();
        }else{
            $(".il_required").hide();
        }
    $('.personstate').on('change',function(){
        if($(".personstate option:selected").val() == "IL"){
            $(".il_required").show();
        }else{
            $(".ilrequired").val('');
            $(".il_required").hide();
            
        }
    });
    $('.btnlicenceclear').on('click',function(){
        $('#bondfile').val(null);
        $('.uploadeddoc_name').val('');
        if($('.mode').val() == 'Edit'){
            var rID = $(this).attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    $('.btnnotaryclear').on('click',function(){
        $('#bondfile').val(null);
        $('.bondfilename').val('');
        if($('.mode').val() == 'Edit'){
            var rID = $(this).attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    $('.btnstdfileclear').on('click',function(){
        $('#bondfile').val(null);
        $('.docname').val('');
        if($('.mode').val() == 'Edit'){
            var rID = $(this).attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    $('.btnilclear').on('click',function(){
        $('.ilphotofield').val(null);
        $('.ipphotoname').val('');
        if($('.mode').val() == 'Edit'){
            var rID = $(this).attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    
    if($('.commissionrenewal:checked').val()=="renewal"){
        $(".addressChange").show();
    }else{
        $(".addressChange").hide();
    }
    $('.commissionrenewal').on('click',function(){
        if($(this).val() == "renewal"){
            $(".addressChange").show();
        }else{
            $(".addressChange").hide();
        }
    });
    $(document).on('change', '.ilphotofield', function(e) {
        $('.ipphotoname').val(e.target.files[0].name+', '+e.target.files[1].name);
        if($('.mode').val() == 'Edit'){
            var rID = $('.btnilclear').attr('data-id');
            $.ajax({
            url: base_url+"transaction/deleteilfile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    $(document).on('change', '.bondfilefield', function(e) {
        $('.bondfilename').val(e.target.files[0].name);
        if($('.mode').val() == 'Edit'){
            var rID = $('.btnnotaryclear').attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    $(document).on('change', '.docimage', function(e) {
        $('.docname').val(e.target.files[0].name);
        if($('.mode').val() == 'Edit'){
            var rID = $('.btnstdfileclear').attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
    if($('.trans_tbl').length > 0){
        transaction_tbl = $('.trans_tbl').DataTable({
            "responsive": true,
            "processing": false,
            "serverSide": true,
            "bAutoWidth": false,
            "dom": '<"head_cover"<"add_user">>rt<"backPagi"p>',
            "iDisplayLength":-1,
            //"scrollY": "500px",
           // "scrollCollapse": true,
            "pageLength": 20,
            "ajax": {
                "url": base_url + "transaction/transaction_tbl",
                "type": "POST"
            },
            columnDefs: [
                { orderable: false, targets: [-1] }
            ],
            oLanguage:  {
                "sSearch": "", 
                oPaginate: {
                  sNext: "<img src='"+base_url+"assets/images/right-arrow.png'>",
                  sPrevious: "<img src='"+base_url+"assets/images/left-arrow.png'>"
               }
            },
            "initComplete": function(settings, json) {
            }
        });
         transaction_tbl.columns().iterator('column', function(ctx, idx){
            $(transaction_tbl.column(idx).header()).append('<span class="sort-icon"/>');
        });
    }
    $('.transactionSearch').on('keyup',function(){
        var table = $('.trans_tbl').DataTable();
        table.search(this.value).draw();
    });
    var table = $('.trans_tbl').DataTable();
        table.column(6).search(1).draw();

    $('.statusSearch').on('change',function(){
        var table = $('.trans_tbl').DataTable();
        table.column(6).search(this.value).draw();
    });
    $('#datetimepicker3').datetimepicker({ 
        //format : 'm-d-Y',
    }).on("dp.change", function (e) {
        $('#datetimepicker4').data("DateTimePicker").minDate(e.date);
        $('#datetimepicker3').data('DateTimePicker').hide();
    });
    $('#datetimepicker4').datetimepicker({
    }).on("dp.change", function (e) {
        $('#datetimepicker3').data("DateTimePicker").maxDate(e.date);
        $('#datetimepicker4').data('DateTimePicker').hide();
    });
    $('#daterangepicker').daterangepicker({
       timePicker: true,
        locale: {
            //format: 'MM-DD-YYYY',
            cancelLabel: 'Clear'
        },
    });
    $('#daterangepicker').on('apply.daterangepicker', function(ev, picker) {
        var table = $('.trans_tbl').DataTable();
        table.columns(0).search(picker.startDate.format('MM/DD/YYYY hh:mm a')+' - '+picker.endDate.format('MM/DD/YYYY  hh:mm a')).draw();
  });
    $('.cancelBtn').on('click', function() {
        var table = $('.trans_tbl').DataTable();
        table.columns(0).search("").draw();
  });
    
   /* $(document).on('change', '.statusSearch', function() {
      var i = '7';  // getting column index
      var v = $(this).val();  // getting search input value
      // dtbid.columns(i).search(v).draw();
      if ($('.trans_tbl').length > 0) {
        transaction_tbl.columns(i).search(v).draw();
      }
    });*/
    $('.typeSearch').on('change',function(){
        var table = $('.trans_tbl').DataTable();
        table.columns(4).search(this.value).draw();
    });
    $(document).on('change', 'select', function() {
        var value = $(this).val();
        var ids = $(this).attr('id');
        if(value != "")
        {
          $(this).next('.select2').find('.select2-selection--single').removeClass('error');
          $(this).next('.select2').find('.select2-selection--multiple').removeClass('error');
          $('#'+ids+'-error').remove();
        }
    });
    $(document).on('click', '.deleteTransaction', function() {
        var rID = $(this).attr('data-id');
        var rTable = $(this).attr('data-table');
        $('.deleteTransactionRecord').attr('data-id',rID);
        $('.deleteTransactionRecord').attr('data-table',rTable);
        $('#deleteTransactions').modal('show');
    });
    $(document).on('click', '.deleteTransactionRecord', function() {
        var rID = $(this).attr('data-id');
        var rTable = $(this).attr('data-table');
        $('#deleteTransactions').modal('hide');
        $('.loadimg').show();
        $.ajax({
            url: base_url+"transaction/deletetransaction",
            type: "POST",
            data:  {'rID':rID,'rTable':rTable},
            success: function(data){
                if(data.status == 'success'){
                    Command: toastr["success"](data.response);
                    var table = $('.trans_tbl').DataTable();
                    table.ajax.reload( null, false ); 
                }else{
                }
                $('.loadimg').hide();
            },
            error: function(){
            }
        });
    });
    $('.phoneformat').mask('(000) 000-0000');
   /* $('.phoneformat').keyup(function()
    {
     //   this.value = this.value.replace(/(\d{3})\-?(\d{3})\-?(\d{4})/g,'$1-$2-$3');;
        var curchr = this.value.length;
    var curval = $(this).val();
    if (curchr == 3) {
        $(this).val("(" + curval + ")");
    } else if (curchr == 8) {
        $(this).val(curval + "-");
    }
    });*/
});
$(document).on('change', '.transactionImage', function(e) {
    $('.uploadeddoc_name').val(e.target.files[0].name);
    if($('.mode').val() == 'Edit'){
            var rID = $('.btnlicenceclear').attr('data-id');
            $.ajax({
            url: base_url+"transaction/deletefile",
            type: "POST",
            data:  {'rID':rID},
            success: function(data){
            },
            error: function(){
            }
        });
        }
    });
$(document).on('click','.backtoIndex',function(){
        window.location = base_url+"transaction";
    });

