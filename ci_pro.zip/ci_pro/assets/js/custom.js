$(document).ready(function(){
	$(document).on('change', '.headSelect', function() {
        var sID = $(this).val();
        if(sID == '0'){
        	window.location.replace(base_url+'auth/logout');
        }
    });
});