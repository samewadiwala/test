<?php
class Acl_Bootstrap extends Zend_Application_Module_Bootstrap
{
	private $routes = array(
		'manage_roles' => array(
			'module' 		=> 'acl',
			'controller' 	=> 'admin_role',
			'action' 		=> 'index',
			'url'			=> 'admin/roles',
		),
		'search_role' => array(
			'module' 		=> 'acl',
			'controller' 	=> 'admin_role',
			'action' 		=> 'search-role',
			'url'			=> 'admin/search-role',
		),
		'delete_role' => array(
			'module' 		=> 'acl',
			'controller' 	=> 'admin_role',
			'action' 		=> 'delete-role',
			'url'			=> 'admin/roles/delete/:id',
		),
		'edit_role' => array(
			'module' 		=> 'acl',
			'controller' 	=> 'admin_role',
			'action' 		=> 'edit-role',
			'url'			=> 'admin/roles/edit/:id',
		),
		'manage_roles_permission' => array(
			'module' 		=> 'acl',
			'controller' 	=> 'admin_role',
			'action' 		=> 'role-permission',
			'url'			=> 'admin/role-permission',
		),
	);
	protected function _initSiteRouters() {
		if(!$this->routes) {
			return;
		}

		foreach ($this->routes as $urlKey => $urlConfig) {
			Zend_Controller_Front::getInstance()->getRouter()->addRoute(
				$urlKey, 
				new Zend_Controller_Router_Route($urlConfig['url'], $urlConfig)
			);
		}
	}
}