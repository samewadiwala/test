<?php
class Acl_Model_Role extends Application_Model_Abstract {
	const ADMIN_ROLE = 1;

    protected $_useUrlHelper        = true;
    protected $_useTranslatorHelper = true;

    protected $_name 		= "role";
	protected $_primary 	= "id";
	protected $_rowClass 	= "Acl_Model_Role_Row";
	protected $_rowsetClass = "Acl_Model_Role_Rowset";

	public function roleValid($data = array()) {

        $errors = array();

        foreach ($data as $key => $value) {
            switch ($key) {
                case 'role_title':
                    
                    $validator = new Zend_Validate_NotEmpty();
                    if(!$validator->isValid($value)){
                        foreach ($validator->getMessages() as $message) {
                            $errors[$key][] = $this->getTranslatorHelper()->Translator()->__("Enter valid Title!");   
                        }
                    } else {
                        $existTitle = $this->getAdapter()->fetchCol(
                            $this->getAdapter()->select()->from($this->_name, array('role_title'=>'LOWER(role_title)'))
                        );

                        if(in_array(strtolower(trim($value)), $existTitle)) {
                            $errors[$key][] = $this->getTranslatorHelper()->Translator()->__("Title Already Exists.");                        
                        }
                    }

                    break;   
            
                default:
                    break;
            }
        }  
        return $errors;
    }

    public function roleUpdateValid($data = array(),$role_id = null) {

        $errors = array();

        foreach ($data as $key => $value) {
            switch ($key) {
                case 'role_title':
                    
                    $validator = new Zend_Validate_NotEmpty();
                    if(!$validator->isValid($value)){
                        foreach ($validator->getMessages() as $message) {
                            $errors[$key][] = "Enter valid Title!";   
                        }
                    } else {
                        $existTitle = $this->getAdapter()->fetchCol(
                            $this->getAdapter()->select()->from($this->_name, array('role_title'=>'LOWER(role_title)'))->where('id <> ?',$role_id)
                        );

                        if(in_array(strtolower(trim($value)), $existTitle)) {
                            $errors['role'.$role_id][] = $this->getTranslatorHelper()->Translator()->__("Title Already Exists.");                        
                        }
                    }

                    break;   
            
                default:
                    break;
            }
        }  
        return $errors;
    }  

    public function getRoleData($data = array()){
        return $this->getResultViaPaginator(
            $this->select()->from($this->_name)
                        ->where('id <> ?',self::ADMIN_ROLE)
                        ->order('created_at DESC')
        );
    }

    public function roleInsert($data = array())
    {
        $errors = $this->roleValid($data);

        if($errors){
            return array(
                'type' => 'failure',
                'html' => $errors
            );
        } else {
            $this->insert($data);
            return array(
                'type' => 'success',
                'html' => $this->getTranslatorHelper()->Translator()->__('Role successfully Inserted.')
            );
        }    
    }

    public function load($id = 0) {
        return $this->fetchRow(
            $this->select()->from($this->_name)->where("id = {$id}")
        );
    }

    public function filter($filter = array(), $sort = null, $order = 'DESC') {
        $filter = array_filter($filter);
        //print_r($filter);die;
        $select = $this->select()
                        ->from($this->_name)
                        ->where('id <> ?',self::ADMIN_ROLE)
                        ->order($sort.' '.$order);
        foreach ($filter as $key => $value) {
            switch ($key) {
                case 'role_title':
                    if($value){
                        $value = trim($value);
                        $select->where("LOWER(role_title) LIKE LOWER('%{$value}%')");
                    }
                break;

                case 'created_at_from':
                    if($value){
                        $select->where("created_at >= '{$filter["created_at_from"]}'");
                    }
                    break;

                case 'created_at_to':
                    if($value){
                        $select->where("created_at <= '{$filter["created_at_to"]}'");
                    }
                    break;

                case 'updated_at_from':
                    if($value){
                        $select->where("updated_at >= '{$filter["updated_at_from"]}'");
                    }
                    break;

                case 'updated_at_to':
                    if($value){
                        $select->where("updated_at <= '{$filter["updated_at_to"]}'");
                    }
                    break;

                default:
                    break;
            }
        }

        //echo $select;die;
        return $this->getResultViaPaginator($select);
    }

    public function updateRecord($data,$id)
    {
        return $this->update($data, "id = {$id}");
    }

    private function getResultViaPaginator($select) {
        return new Zend_Paginator(
            new Zend_Paginator_Adapter_DbSelect($select)
        );
    }
}