<?php
	class Acl_Model_Role_Rowset extends Zend_Db_Table_Rowset_Abstract {
		protected $_tableClass = "Acl_Model_Role";	
	}
?>