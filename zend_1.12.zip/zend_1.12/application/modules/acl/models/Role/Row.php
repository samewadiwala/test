<?php
	class Acl_Model_Role_Row extends Zend_Db_Table_Row_Abstract {
		protected $_tableClass = "Acl_Model_Role";
	}
?>