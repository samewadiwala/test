<?php
	class Acl_Admin_RoleController extends Controller_AdminAbstract
	{
		private $roleModel 	 = null;
		private $userModel 	 = null;
		private $configModel = null;

		/*public function preDispatch()
	    {
	    	parent::preDispatch();

	    	if(!$this->_getSession()->token) {
	    		$this->_redirect("backoffice");
	    	}

	    	$this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');
			$this->initView();
	    }*/

		public function indexAction() {
			$this->view->headTitle($this->view->Translator()->__('Manage roles'));
			$this->_helper->layout->setLayout('admin/template-account');

			$this->view->headScript()->appendFile($this->view->baseUrl('public/js/acl/role/role.js'));

			$this->view->session = unserialize($this->_getSession()->adminUser);
			$userbase = unserialize($this->_getSession()->adminUser);
			$id = $userbase['id'];

			$this->view->roleData = $this->_getRoleModel()->getRoleData();
			$this->view->filter 	= array();	
			$this->view->sort 		= 'created_at';
			$this->view->order 		= 'DESC';
			if($this->getRequest()->isPost()) {
				$this->_helper->layout->disableLayout();
				$this->_helper->viewRenderer->setNoRender(true);
				$data 		= $this->getRequest()->getPost('role',array());
				try{
					$date       = Zend_Date::now();
            		$timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());

            		$data['created_at'] = $timeStamp; 
					$response 	= $this->_getRoleModel()->roleInsert($data);
					$this->view->roleData =$this->_getRoleModel()->getRoleData();
					if($response['type'] == 'success'){
						$response = array(
							'type' => 'success',
							'msg'  => $this->view->Translator()->__('Role successfully inserted!'),
							'html' => $this->view->partial('admin/role/index/role-list.phtml',null,$this->view->getVars())
						);
					}
				} catch(Exception $e ) {
					$response = array(
						'type' => 'failure',
						'html' => array('role_title'=>array($this->view->Translator()->__('Something went wrong!'))),
						// 'html' => array('role_title'=>array(
						// 	$e->getMessage()
						// )),
					);
				}
				$this->getResponse()->setBody(json_encode($response));
				return;
			}
		}

		public function searchRoleAction() {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);

			$response = array();

			if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
				$response['type'] 	= "error";
				$response['msg']	= $this->view->Translator()->__("Invalid request");

				$this->getResponse()->setBody(json_encode($response));
				return;
			}
			$sort = $this->getRequest()->getParam('sort', 'created_at');
			$order = $this->getRequest()->getParam('order', 'DESC');

			$filter	= $this->getRequest()->getPost('filter', array());
			
			$this->view->roleData = $this->_getRoleModel()->filter($filter, $sort, $order);
			$this->view->roleData->setCurrentPageNumber($this->getRequest()->getParam('page', 1));

			$this->view->filter = $filter;
			$this->view->sort 	= $sort;
			$this->view->order 	= $order;
			
			$response['html']	= $this->view->partial("admin/role/index/role-list.phtml", null, $this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));

			return;
		}

		public function editRoleAction(){
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);

			$response = array();

			if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
				$response['type'] 	= "error";
				$response['msg']	= $this->view->Translator()->__("Invalid Request!");

				$this->getResponse()->setBody(json_encode($response));
				return;
			}

			try{
				$id = $this->getRequest()->getParam('id', 0);

				$roleUpdateData	= $this->getRequest()->getPost('roleEdit', array());
				$errors = $this->_getRoleModel()->roleUpdateValid($roleUpdateData,$id);

		        if($errors){
		        	$response = array(
		                'type' => 'failure',
		                'html' => $errors
		            );
		        } else {
		        	$date       = Zend_Date::now();
            		$timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());

            		$roleUpdateData['updated_at'] = $timeStamp; 
					$this->_getRoleModel()->updateRecord($roleUpdateData,$id);

					$sort = $this->getRequest()->getParam('sort', 'created_at');
					$order = $this->getRequest()->getParam('order', 'DESC');

					$filter	= $this->getRequest()->getPost('filter', array());

					$this->view->roleData = $this->_getRoleModel()->filter($filter, $sort, $order);
					$this->view->roleData->setCurrentPageNumber($this->getRequest()->getParam('page', 1));

					$this->view->filter = $filter;
					$this->view->sort 	= $sort;
					$this->view->order 	= $order;

					$response = array(
						'type' 	=> 'success',
						'msg' 	=> 'Role successfully updated.',
						'html' 	=> $this->view->partial("admin/role/index/role-list.phtml", null, $this->view->getVars())
					);
				}
			} catch(Exception $e) {
				$response = array(
					'type' 	=> 'failure',
					'html' 	=> array( 'role'.$id => array(
						$this->view->Translator()->__('Something went wrong!')
					)),
				);
			}
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		public function deleteRoleAction() {
			$id 	= $this->getRequest()->getParam('id', 0);

			$role 	= $this->_getRoleModel()->load($id);

			if(!$role) {
				//$this->_flashMessenger->addMessage($this->view->Translator()->__("Requested record does not exist."), 'error');
				$this->_redirect('admin/roles');
			}

			try {
				$role->delete();
				
				//$this->_flashMessenger->addMessage($this->view->Translator()->__('Role Deleted Successfully.'), 'success');
				$this->_redirect('admin/roles');
			} catch (Exception $e) {
				$this->_flashMessenger->addMessage($this->view->Translator()->__($e->getMessage()), 'error');
			}
		}
		
		protected function _getSession() {
			return new Zend_Session_Namespace("ad-master");
		}

		protected function _getConfigModel() {
			if(is_null($this->configModel)){
				$this->configModel = new System_Model_Configuration();
			}
			return $this->configModel;
		}

		protected function _getRoleModel()
		{
			if(is_null($this->roleModel)){
				$this->roleModel = new Acl_Model_Role();
			}
			return $this->roleModel;
		}

		public function _getUserdModel(){
            if(is_null($this->userModel)) {
                $this->userModel = new Account_Model_User();
            }
            return $this->userModel;
        }
	}
?>