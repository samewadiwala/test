<?php
class Student_Bootstrap extends Zend_Application_Module_Bootstrap {
    
    private $routes = array(
        'student' => array(
            'module'        => 'student',
            'controller'    => 'student',
            'action'        => 'index',
            'url'           => 'student-detail',
        ),
    );

    protected function _initSiteRouters() {
        if(!$this->routes) {
            return;
        }

        foreach ($this->routes as $urlKey => $urlConfig) {
            Zend_Controller_Front::getInstance()->getRouter()->addRoute(
                $urlKey, 
                new Zend_Controller_Router_Route($urlConfig['url'], $urlConfig)
            );
        }
    }
}