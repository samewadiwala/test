<?php

class Student_Model_Student extends Zend_Db_Table_Abstract {
	
	protected $_name    = 'student';
	protected $_primary = 's_id';

	public function getAllStudents(){
		$select = $this->select()->from($this->_name);
		return $this->fetchAll($select);
    }

    /*$row = $this->fetchRow(
    			$this->select()->from($this->_name)->where("email = ? OR username = ?", $username, $username)->where("u_role = ?", self::ROLE_ADMIN)->where("status = ?", self::STATUS_ACTIVE)
    		);*/
}
