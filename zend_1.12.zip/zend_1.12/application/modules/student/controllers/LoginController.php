<?php
include_once 'library/Google/contrib/Google_Oauth2Service.php';

class Account_User_LoginController extends Controller_AuthAbstract
{
	private $userModel 		= null;
	private $validateModel 	= null;
	private $profileModel 	= null;
	private $wallModel 		= null;
	private $facebookModel 	= null;

	private $facebookScop   = array('email','user_friends');

	public function preDispatch() {
    	parent::preDispatch();
    	if($this->_getSession()->token) {
    		$this->_redirect("dashboard");
    	}
    }

	public function loginAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$this->_redirect('/');
		}

		$data 	= $this->getRequest()->getPost();
		$errors = $this->_getvalidateModel()->loginValidate($data);
		if($errors) {
			$response = array(
				'type'	=> 'failure',
				'html'  => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		try{
			$resp = $this->_getUserModel()->userLogin($data);
			if($resp)
			{
				$this->_getSession()->token = session_id();
				$response['type'] = 'success';
				$response['url'] = $this->view->url(array(), 'user_product_listing');
			} else {
				$response['type'] = 'failure';

        		$row = $this->_getUserModel()->getUserAccountDetail($data);

                if(count($row)){
                	switch ($row['status']) {
                		case Account_Model_User::STATUS_WAITING_FOR_USER:
								$response['html'] = array( 
									'login' => array(
										$this->view->Translator()->__("You have not confirm your email yet.")
									)
								);
                			break;

                		case Account_Model_User::STATUS_SUSPENDED:
                				$response['html'] = array( 
									'login' => array(
										$this->view->Translator()->__("Your account has been suspended.")
									)
								);
                			break;

                		case Account_Model_User::STATUS_DELETE_BY_USER:
                				$response['html'] = array( 
									'login' => array(
										$this->view->Translator()->__("Your account has been deleted.")
									)
								);
                			break;
                			
                		default:
                			$response['html'] = array( 
								'login' => array(
									$this->view->Translator()->__("Invalid credentials, please try again.")
								)
							);
                			break;
                	}
                } else {
					$response['html'] = array( 
						'login' => array(
							$this->view->Translator()->__("Invalid credentials, please try again.")
						)
					);
                }
			}	
		} catch (Exception $e) {
			$response = array(
                'type' => 'failure',
                'html' => array(
                    'login' => array($e->getMessage())
                )
            ); 
        }

		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function loginFacebookAction(){
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		$facebookAppID 		= $this->view->Config('facebook_app_id');
		$facebookAppSecret 	= $this->view->Config('facebook_app_secret');

		Facebook_FacebookSession::setDefaultApplication( $facebookAppID, $facebookAppSecret );
		
		$http  	= isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
		$url 	= $http.''.$_SERVER['HTTP_HOST'].''.$this->view->baseUrl().'/login/facebook';

		$helper = new Facebook_FacebookRedirectLoginHelper($url);

		try {
		    $session = $helper->getSessionFromRedirect();
			
			if ( isset( $session ) ) {
			    $request = new Facebook_FacebookRequest( 
			    	$session, 
			    	'GET', 
			    	'/me?fields=id,name,cover,email,first_name,gender,last_name,link' 
			    );

			    $response 	= $request->execute();
	
			    $fbData   	= $response->getResponse();

			    $fbData		= get_object_vars($fbData);
			    
			  	$fbData['cover'] = is_object($fbData['cover']) ? get_object_vars($fbData['cover']) : array();  
   
				$users = $this->_getUserModel()->getUserDeatil($fbData['email']);
	   
			    if($users){
			    	$date       = Zend_Date::now();
	        		$timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());
		    		$updateData = array(
		    			'last_login'		=> $timeStamp,
		    			'updated_date'		=> $timeStamp,
		    		);

		    		if(!$users['facebook_user_id']){
		   				$updateData['facebook_user_id']	= $fbData['id'];
		    		}

					$this->_getUserModel()->update($updateData,'id = '.$users['id']);	
			    	
			    	$this->_getSession()->token = session_id();
					$this->_getSession()->user = serialize($users);

					if($this->_getSession()->token) {
			    		$this->_redirect("dashboard");
			    	}
			    } else {
			    	$respFacebook = $this->_getUserModel()->registerUserFacebook($fbData);

			    	if($this->_getSession()->token) {
				    	if($users['u_password']){
					    	$this->_redirect("dashboard");
				    	} else {
			    			//var_dump($users['u_password']);die;
				    		$this->_redirect("user/secure-account");
				    	}
				    }

			    }
			} else {
				if($this->getRequest()->isXmlHttpRequest() && $this->getRequest()->isPost()) {
					$this->_helper->layout->disableLayout();
					$this->_helper->viewRenderer->setNoRender(true);
				    
				    $response['type'] = 'fb_login';
					$response['url']  = $helper->getLoginUrl($this->facebookScop);

					$this->getResponse()->setBody(json_encode($response));
					return;
				}
			}

		} catch( Facebook_FacebookRequestException $e ) {
		  	$response = array('type' => 'failure', 'error' => $e->getMessage());
        	Zend_Registry::get('logger')->log(sprintf('%s in %s on line %d', $e->getMessage(), __FILE__, __LINE__), 3);
		} catch( Exception $e ) {
		  	$response = array('type' => 'failure', 'error' => $e->getMessage());
        	Zend_Registry::get('logger')->log(sprintf('%s in %s on line %d', $e->getMessage(), __FILE__, __LINE__), 3);
		}

		if($response){
			throw new Zend_Controller_Action_Exception($response['error'], 403);
		} else {
			$this->_redirect("");
		}
	}

	public function loginGplusAction(){
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		$googleClientID 		= $this->view->Config('google_client_id');
		$googleClientSecret 	= $this->view->Config('google_client_secret');
		$googleClientApp 		= $this->view->Config('google_app_name');

		$http  	= isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
		$url 	= $http.''.$_SERVER['HTTP_HOST'].''.$this->view->baseUrl().'/login/gplus';

		try {
			
			$gClient = new Google_Client();
			$gClient->setApplicationName($googleClientApp);
			$gClient->setClientId($googleClientID);
			$gClient->setClientSecret($googleClientSecret);
			$gClient->setRedirectUri($url);

			$google_oauthV2 = new Google_Oauth2Service($gClient);

			$code = $this->getRequest()->getParam('code',null);
			
			if($code){
				$gClient->authenticate($code);
				$this->_getSession()->g_token = $gClient->getAccessToken();
				$this->_redirect("login/gplus");	
			}
					
		    $accessToken = $this->_getSession()->g_token;
		   
			if ( isset( $accessToken ) ) {
				$gClient->setAccessToken($accessToken);
			    $gpData  = $google_oauthV2->userinfo->get();

				$users = $this->_getUserModel()->getUserDeatil($gpData['email']);
	   
			    if($users){
			    	$date       = Zend_Date::now();
	       			$timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());
		    		$updateData = array(
		    			'last_login'		=> $timeStamp,
		    			'updated_date'		=> $timeStamp,
		    		);

		    		if(!$users['google_user_id']){
		   				$updateData['google_user_id']	= $gpData['id'];
		    		}

					$this->_getUserModel()->update($updateData,'id = '.$users['id']);	
			    	
			    	$this->_getSession()->token = session_id();
					$this->_getSession()->user = serialize($users);

					if($this->_getSession()->token) {
			    		$this->_redirect("dashboard");
			    	}
			    } else {
			    	$respGoogle = $this->_getUserModel()->registerUserGoogle($gpData);
			    	
			    	if($this->_getSession()->token) {
				    	if($users['u_password']){
					    	$this->_redirect("dashboard");
				    	} else {
			    			//var_dump($users['u_password']);die;
				    		$this->_redirect("user/secure-account");
				    	}
				    }
			    }
			} else {
				if($this->getRequest()->isXmlHttpRequest() && $this->getRequest()->isPost()) {
					$this->_helper->layout->disableLayout();
					$this->_helper->viewRenderer->setNoRender(true);
				    
				    $response['type'] = 'gp_login';
					$response['url']  = filter_var($gClient->createAuthUrl(), FILTER_SANITIZE_URL);

					$this->getResponse()->setBody(json_encode($response));
					return;
				}
			}
		} catch( Exception $e ) {
		  	$response = array('type' => 'failure', 'error' => $e->getMessage());
        	Zend_Registry::get('logger')->log(sprintf('%s in %s on line %d', $e->getMessage(), __FILE__, __LINE__), 3);
		}

		if($response){
			throw new Zend_Controller_Action_Exception($response['error'], 403);
		} else {
			$this->_redirect("");
		}
	}

	public function _getvalidateModel(){
        if(is_null($this->validateModel)) {
            $this->validateModel = new Account_Model_User_Validate();
        }
        return $this->validateModel;
    }
	
	protected function _getUserModel() {
		if(is_null($this->userModel)) {
			$this->userModel = new Account_Model_User();
		}
		return $this->userModel;
	}

	protected function _getFacebookModel() {
		if(is_null($this->facebookModel)) {
			$this->facebookModel = new Account_Model_Facebook();
		}
		return $this->facebookModel;
	}

	protected function _getUserProfileModel() {
        if(is_null($this->profileModel)) {
            $this->profileModel = new Account_Model_User_Profile();
        }
        return $this->profileModel;
    }

    protected function _getUserWallModel() {
        if(is_null($this->wallModel)) {
            $this->wallModel = new Account_Model_User_Wall();
        }
        return $this->wallModel;
    }

	protected function _getSession() {	
		return new Zend_Session_Namespace("ad-user");
	}
}
?>