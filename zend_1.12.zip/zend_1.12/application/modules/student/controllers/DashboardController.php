<?php
class Account_User_DashboardController extends Controller_Abstract {
	const ADMIN = 1;
	
	private $userModel 				= null;
	private $wallModel 				= null;
	private $validateModel 			= null;
	private $profileModel 			= null;
	private $productModel 			= null;
	private $paymentModel 			= null;
	private $studentProductModel 	= null;
	private $reviewModel 			= null;
	private $instrctorBalanceModel 	= null;

	private $emailNotificationModel 			= null;
	private $instrctorEarningTransactionModel 	= null;

	public function dashboardAction() {
		$this->view->headTitle($this->view->Translator()->__('Dashboard'));
		$this->_helper->layout->setLayout('layout');

		$userbase = unserialize($this->_getSession()->user);
		
		$this->view->userid = $userbase['id'];
		$this->view->session = $userbase;
		
		$this->view->userData = $this->_getUserModel()->getUserDeatilById($userbase['id']);

		$this->view->totalCourses 	= count($this->_getProductModel()->getProductsByUserID($userbase['id']));
		$this->view->totalClasses 	= count($this->_getProductModel()->getProductsByUserID($userbase['id'],Catalog_Model_Product::TYPE_CLASS));
		$this->view->totalPublishCourses = count($this->_getProductModel()->getPublishProductByUserID($userbase['id']));
		$this->view->totalPublishClasses = count($this->_getProductModel()->getPublishProductByUserID($userbase['id'],Catalog_Model_Product::TYPE_CLASS));
		$this->view->totalRevenue   = $this->_getInstrctorEarningTransactionModel()->getRevenueByUserId($userbase['id']);
		$this->view->totalBalance   = $this->_getInstrctorBalanceModel()->getBalanceByUserId($userbase['id']);
		$this->view->totalStudent   = count($this->_getStudentProductModel()->getTotalStudentsByUserId($userbase['id']));
		$this->view->avgRating   	= $this->_getReviewModel()->getAverageReviewByInsturctorId($userbase['id']);
		
		$this->view->myCourse 		= count($this->_getStudentProductModel()->getCourseByUserId($userbase['id']));
		$this->view->myClass 		= count($this->_getStudentProductModel()->getClassByUserId($userbase['id']));

		$this->view->ref = $this->getRequest()->getParam('ref','student');
		$this->view->uri = $this->view->url(array(),'user_dashboard');
	}

	public function instructorDashboardAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		$userbase = unserialize($this->_getSession()->user);
		$userid = $userbase['id'];
		//$this->view->userWallData = $this->_getUserWallModel()->getWallByUserId($userid);

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);
			
			$this->view->totalCourses 	= count($this->_getProductModel()->getProductsByUserID($userbase['id']));
			$this->view->totalClasses 	= count($this->_getProductModel()->getProductsByUserID($userbase['id'],Catalog_Model_Product::TYPE_CLASS));
			$this->view->totalPublishCourses = count($this->_getProductModel()->getPublishProductByUserID($userbase['id']));
			$this->view->totalPublishClasses = count($this->_getProductModel()->getPublishProductByUserID($userbase['id'],Catalog_Model_Product::TYPE_CLASS));
			$this->view->totalRevenue   = $this->_getInstrctorEarningTransactionModel()->getRevenueByUserId($userbase['id']);
			$this->view->totalBalance   = $this->_getInstrctorBalanceModel()->getBalanceByUserId($userbase['id']);
			$this->view->totalStudent   = count($this->_getStudentProductModel()->getTotalStudentsByUserId($userbase['id']));
			$this->view->avgRating   	= $this->_getReviewModel()->getAverageReviewByInsturctorId($userbase['id']);
			
			$response = $this->view->partial('user/dashboard/dashboard/instructor.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
	}

	public function studentDashboardAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		$userbase = unserialize($this->_getSession()->user);
		$userid = $userbase['id'];
		$this->view->userWallData = $this->_getUserWallModel()->getWallByUserId($userid);

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);

			$this->view->myCourse 		=  count($this->_getStudentProductModel()->getCourseByUserId($userbase['id']));
			$this->view->myClass 		=  count($this->_getStudentProductModel()->getClassByUserId($userbase['id']));
			
			$response = $this->view->partial('user/dashboard/dashboard/student.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
	}

	public function profileAction() {
		$this->view->headTitle($this->view->Translator()->__('Profile'));
		$this->_helper->layout->setLayout('layout');

		//$this->view->headLink()->appendStylesheet($this->view->baseUrl('public/css/dashboard.css'))
								;

		$this->view->headScript()
						->appendFile($this->view->baseUrl('public/js/account/profile.js'))
						->appendFile($this->view->baseUrl('public/js/mask.min.js'))
						->appendFile($this->view->baseUrl('public/js/account/dashboard/change-email.js'))
						->appendFile($this->view->baseUrl('public/js/account/dashboard/change-username.js'))
						->appendFile($this->view->baseUrl('public/js/ckeditor/ckeditor.js'))
						;

		$userbase = unserialize($this->_getSession()->user);
		$this->view->ref = $this->getRequest()->getParam('ref','profile');
		$this->view->uri = $this->view->url(array(),'user_profile');
		$this->view->userid = $userbase['id'];
		$this->view->session = $userbase;
		$this->view->userData = $this->_getUserModel()->getUserDeatilById($userbase['id']);
		
		$this->view->profileData = $this->_getUserProfileModel()->getProfileByUserId($userbase['id']);
		
		$this->view->userWallData = $this->_getUserWallModel()->getWallByUserId($userbase['id']);
		$this->view->user = $this->view->userData;

		$this->view->paymentDetail 	= $this->_getUserPaymentModel()->getPaymentDetailByUserId($userbase['id']);

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);
			$response = $this->view->partial('user/dashboard/profile/profile.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isPost() && $this->getRequest()->isXmlHttpRequest()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);

			$response = array();
			$postData = $this->getRequest()->getPost('profile',array());
			$userData = $this->getRequest()->getPost('users',array());
			
			$errors = $this->_getvalidateModel()->validProfile($postData,$userData);
			if($errors){
				$response = array(
					'type' => 'failure',
					'html' => $errors
				);
				$this->getResponse()->setBody(json_encode($response));
				return;
			}

			try{
				$postData['user_id'] = $userbase['id'];
				$postData['gender']  = $postData['prefix'];
				if($postData['dob']) {
					$postData['dob'] = date('Y-m-d',strtotime($postData['dob']));
				} else {
					unset($postData['dob']);
				}

				if($this->view->profileData){
					$this->_getUserProfileModel()->update($postData, 'user_id = '.$userbase["id"]);
				} else{
					$this->_getUserProfileModel()->insert($postData);
				}

				$this->_getUserModel()->update($userData,'id='.$userbase["id"]);
				$this->view->profileData = $this->_getUserProfileModel()->getProfileByUserId($userbase['id']);
				$this->view->userData = $this->_getUserModel()->getUserDeatilById($userbase['id']);
				
				$response = array(
					'type' => 'success',
					'msg'  => $this->view->Translator()->__('Profile updated successfully.'),
					'html' => $this->view->partial('user/dashboard/profile/profile.phtml', null, $this->view->getVars()),
					'profile_pic' => $this->view->partial('user/dashboard/profile/profile-picture.phtml',null,$this->view->getVars()),
					'username' => $this->view->Translator()->__('Hi') .', '.$this->view->userData['first_name'],
				);
				
			} catch(Exception $e) {
				$response = array(
					'type' => 'failure',
					//'msg'  => $this->view->Translator()->__('Something went wrong.')
					'msg'  => $e->getMessage()
				);
			}

			$this->getResponse()->setBody(json_encode($response));
			return;
		}
	}

	public function wallSettingAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		$userbase = unserialize($this->_getSession()->user);
		$userid = $userbase['id'];
		$this->view->userWallData = $this->_getUserWallModel()->getWallByUserId($userid);

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid Request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);
			$response = $this->view->partial('user/dashboard/profile/wall-setting.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && $this->getRequest()->isPost()) {
			$date       = Zend_Date::now();
	        $timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());
	        $userWallData = $this->_getUserWallModel()->getWallByUserId($userid);

	        $postData = $this->getRequest()->getPost('wall',array());
	        
	        try{
	        	if($userWallData){   
			        $postData['updated_date'] = $timeStamp;     
			        $this->_getUserWallModel()->update($postData, "user_id = ".$userid);
				} else {
					$postData['user_id'] 		= $userid;
		            $postData['profile_pic']   	= ''; 
					$postData['updated_date'] 	= $timeStamp; 
			        
					$this->_getUserWallModel()->insert($postData);
				}
				$this->view->userWallData = $this->_getUserWallModel()->getWallByUserId($userid);
				$this->view->userData 	  = $this->_getUserModel()->getUserDeatilById($userid);
				$response = array(
					'type' => 'success',
					'msg'  => $this->view->Translator()->__('Wall settings updated successfully.'),
					'html' => $this->view->partial('user/dashboard/profile/wall-setting.phtml',null,$this->view->getVars()),
					'profile_pic' => $this->view->partial('user/dashboard/profile/profile-picture.phtml',null,$this->view->getVars()),
					'username' => $this->view->Translator()->__('Hi') .', '.$this->view->userData['first_name'],
				);
	        } catch(Exception $e){
	        	$response = array(
					'type' => 'failure',
					//'msg'  => $this->view->Translator()->__('Something went wrong.')
					'msg'  => $e->getMessage()
				);
	        }
	        $this->getResponse()->setBody(json_encode($response));
			return;   
		}
	}

	public function accountAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);
			$userbase = unserialize($this->_getSession()->user);
			$userid = $userbase['id'];
			$this->view->user = $this->_getUserModel()->getUserDeatilById($userid);
			$response = $this->view->partial('user/dashboard/profile/account.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		//$response = $this->view->partial('user/dashboard/index/account.phtml',null,$this->view->getVars());
		//$this->getResponse()->setBody(json_encode($response));
		//return;
	}

	public function paymentAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$userbase = unserialize($this->_getSession()->user);
		$userid = $userbase['id'];

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->view->user 			= $this->_getUserModel()->getUserDeatilById($userid);
			$this->view->paymentDetail 	= $this->_getUserPaymentModel()->getPaymentDetailByUserId($userid);
			$response 					= $this->view->partial('user/dashboard/profile/payment.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && $this->getRequest()->isPost()) {
			$response = array();
			$paymentData 	= $this->_getUserPaymentModel()->getPaymentDetailByUserId($userid);
			$postData 		= $this->getRequest()->getPost('payment', array());

			$errors = $this->_getvalidateModel()->validPaymentDetail($postData);
			if($errors){
				$response = array(
					'type' => 'failure',
					'html' => $errors
				);
				$this->getResponse()->setBody(json_encode($response));
				return;
			}

			try{
				$postData['user_id'] = $userid;

				if($paymentData){
					$this->_getUserPaymentModel()->update($postData, "user_id = ".$userid);
				} else {
					$this->_getUserPaymentModel()->insert($postData);
				}

				$this->view->paymentDetail 	= $this->_getUserPaymentModel()->getPaymentDetailByUserId($userid);

				$response = array(
					'type' => 'success',
					'msg'  => $this->view->Translator()->__('Payment detail updated successfully.'),
					'html' => $this->view->partial('user/dashboard/profile/payment.phtml',null,$this->view->getVars()),
				);
				
			} catch(Exception $e){
				$response = array(
					'type' => 'failure',
					'html' => $e->getMessage()
				);
			}

			$this->getResponse()->setBody(json_encode($response));
			return;
		}
	}

	public function imageAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];

		$errors = $this->_getvalidateModel()->validProfilePic($_FILES);
		if($errors){
			$response = array(
				'type' => 'failure',
				'msg' => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
		try{
			$http  			= isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
			$storage_path 	= $http.''.$_SERVER['HTTP_HOST'].''.$this->view->baseUrl().'/'.Account_Model_User_Wall::IMAGEPATH;

			$this->_getUserWallModel()->changeProfilePic($_FILES, $userbase["id"], $storage_path);
		
			$userWallData = $this->_getUserWallModel()->getWallByUserId($userbase['id']);
			
			$response = array(
				'type' => 'success',
				'msg'  => $this->view->Translator()->__('Profile picture updated successfully.'),
				//'src' => $this->view->baseUrl($userWallData['profile_pic']),
				'src' => $userWallData['profile_pic'],
			);

		} catch (Exception $e){
			$response = array(
				'type' => 'failure',
				//'msg'  => $this->view->Translator()->__('Something went wrong.')
				'msg'  => $e->getMessage()
			);
		}
	
		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function coverImageAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];

		$errors = $this->_getvalidateModel()->validProfilePic($_FILES);
		if($errors){
			$response = array(
				'type' => 'failure',
				'msg' => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
		try{
			$http  			= isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
			$storage_path 	= $http.''.$_SERVER['HTTP_HOST'].''.$this->view->baseUrl().'/'.Account_Model_User_Wall::IMAGEPATH;

			$this->_getUserWallModel()->changeCoverPic($_FILES, $userbase["id"], $storage_path);
		
			$userWallData = $this->_getUserWallModel()->getWallByUserId($userbase['id']);
			
			$response = array(
				'type' => 'success',
				'msg'  => $this->view->Translator()->__('Cover image updated successfully.'),
				//'src' => $this->view->baseUrl($userWallData['cover_pic']),
				'src' => $userWallData['cover_pic'],
			);

		} catch (Exception $e){
			$response = array(
				'type' => 'failure',
				//'msg'  => $this->view->Translator()->__('Something went wrong.')
				'msg'  => $e->getMessage()
			);
		}
	
		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function changeUsernameAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];

		$username = $this->getRequest()->getPost('username','');

		$errors = $this->_getvalidateModel()->validUsername($username,$id);
		if($errors){
			$response = array(
				'type' => 'failure',
				'html' => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		try{
			$date       = Zend_Date::now();
	    	$timeStamp  = gmdate("Y-m-d H:i:s", $date->getTimestamp());

			$data['username'] = $username;
			$data['updated_date'] = $timeStamp;
			$this->_getUserModel()->update($data,'id = '.$id);
			$this->view->user = $this->_getUserModel()->getUserDeatilById($id);
			$response = array(
				'type' => 'success',
				'msg' => $this->view->Translator()->__("Username changed successfully."),
				'html' => $this->view->partial('user/dashboard/profile/account.phtml',null,$this->view->getVars()),
			);
		} catch(Exception $e){
			$response = array(
				'type' => 'failure',
				'html' => $e->getMessage()
			);
		}

		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function changeEmailAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];

		$data = $this->getRequest()->getPost('change_email',array());

		$errors = $this->_getvalidateModel()->validChangeEmail($data,$id);
		if($errors){
			$response = array(
				'type' => 'failure',
				'html' => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		try{
			
			$response = $this->_getUserModel()->changeEmail($data);
			$this->view->user = $this->_getUserModel()->getUserDeatilById($id);
			$this->_getEmailNotificationModel()
	                    ->addTo($data['email'])
	                    ->setSubject($this->view->Translator()->__('AdvanEDU : Email changed'))
	                    ->setVars(
	                        array('email' => $data['email'],'user' => $this->view->user)
	                        )
	                    ->setTemplate('emails/change-email.phtml')
	                    ->send()  
	                    ;
			if($response['type'] == 'success'){
				$response['email'] = $data['email'];
				$response['modal'] = 'change-email';
			}
		} catch(Exception $e){
			$response = array(
				'type' => 'failure',
				'html' => $e->getMessage()
			);
		}

		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function changePasswordAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$data	 = $this->getRequest()->getPost('password', array());

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];
		
		$errors = $this->_getvalidateModel()->validUserChangePassword($data);
		if($errors){
			$response = array(
				'type' => 'failure',
				'html' => $errors
			);
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
		try{
			$this->_getUserModel()->update(array('u_password' => md5($data['new_password'])), "id = {$id}");
			$userData = $this->_getUserModel()->getUserDeatilById($id);
			$this->_getEmailNotificationModel()
	                    ->addTo($userData['email'])
	                    ->setSubject($this->view->Translator()->__('AdvanEDU : Password changed'))
	                    ->setVars(
	                        array('user' => $userData)
	                        )
	                    ->setTemplate('emails/change-password.phtml')
	                    ->send()  
	                    ;
			$response = array(
				'type' => 'success',
				'html' => $this->view->Translator()->__("Password successfuly changed!"),
				'msg' => $this->view->Translator()->__("Password successfuly changed!")
			);
		} catch(Exception $e){
			$response = array(
				'type' => 'failure',
				'html' => array('changepassword' => array( $e->getMessage()))
			);
		}
		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function dangerZoneAction() {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		if($this->getRequest()->isXmlHttpRequest() && !$this->getRequest()->isPost()) {
			$this->_helper->layout->disableLayout();
			$this->_helper->viewRenderer->setNoRender(true);
			$userbase = unserialize($this->_getSession()->user);
			$userid = $userbase['id'];
			$this->view->user = $this->_getUserModel()->getUserDeatilById($userid);
			$response = $this->view->partial('user/dashboard/profile/danger-zone.phtml',null,$this->view->getVars());
			$this->getResponse()->setBody(json_encode($response));
			return;
		}
	}

	public function deleteAccountAction() {
		//STATUS_DELETE_BY_USER
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$response = array();

		if(!$this->getRequest()->isPost() || !$this->getRequest()->isXmlHttpRequest()) {
			$response['type'] 	= "error";
			$response['msg']	= $this->view->Translator()->__("Invalid request");
			$this->getResponse()->setBody(json_encode($response));
			return;
		}

		$user_id	 = $this->getRequest()->getPost('id', array());

		$userbase = unserialize($this->_getSession()->user);
		$id = $userbase['id'];
		
		try{
			$this->_getUserModel()->update(array('status' => Account_Model_User::STATUS_DELETE_BY_USER), "id = {$user_id}");
			$userData = $this->_getUserModel()->getUserDeatilById($id);
			$this->_getEmailNotificationModel()
	                    ->addTo($userData['email'])
	                    ->setSubject($this->view->Translator()->__('AdvanEDU : Account deleted'))
	                    ->setVars(
	                        array('user' => $userData)
	                        )
	                    ->setTemplate('emails/account-delete.phtml')
	                    ->send()  
	                    ;
	        $adminData = $this->_getUserModel()->getUserDeatilById(self::ADMIN);
	        $this->_getEmailNotificationModel()
	                    ->addTo($adminData['email'])
	                    ->setSubject($this->view->Translator()->__('AdvanEDU : Account deleted'))
	                    ->setVars(
	                        array('user' => $userData)
	                        )
	                    ->setTemplate('emails/account-delete.phtml')
	                    ->send()  
	                    ;
			$this->_getUserModel()->logout();
			$response = array(
				'type' => 'success',
				//'html' => $this->view->Translator()->__("Password Successfuly Changed!"),
				'msg' => $this->view->Translator()->__("Account deleted successfully."),
				'url' => $this->view->baseUrl(),
				'modal' => 'delete-account-modal'
			);
		} catch(Exception $e){
			$response = array(
				'type' => 'failure',
				'html' => $e->getMessage()
			);
		}
		$this->getResponse()->setBody(json_encode($response));
		return;
	}

	public function logoutAction() {
		if($this->_getUserModel()->logout()){
			$this->_redirect("");
		}
	}

	protected function _getUserModel() {
		if(is_null($this->userModel)) {
			$this->userModel = new Account_Model_User();
		}
		return $this->userModel;
	}

	protected function _getProductModel() {
		if(is_null($this->productModel)) {
			$this->productModel = new Catalog_Model_Product();
		}
		return $this->productModel;
	}

	protected function _getUserProfileModel() {
		if(is_null($this->profileModel)) {
			$this->profileModel = new Account_Model_User_Profile();
		}
		return $this->profileModel;
	}

	protected function _getUserWallModel() {
		if(is_null($this->wallModel)) {
			$this->wallModel = new Account_Model_User_Wall();
		}
		return $this->wallModel;
	}

	protected function _getUserPaymentModel() {
		if(is_null($this->paymentModel)) {
			$this->paymentModel = new Account_Model_User_PaymentDetail();
		}
		return $this->paymentModel;
	}

	protected function _getStudentProductModel() {
		if(is_null($this->studentProductModel)) {
			$this->studentProductModel = new Account_Model_User_StudentProduct();
		}
		return $this->studentProductModel;
	}

	public function _getInstrctorBalanceModel() {
		if(is_null($this->instrctorBalanceModel)) {
			$this->instrctorBalanceModel = new Account_Model_User_InstructorBalance();
		}
		return $this->instrctorBalanceModel;
	}

	public function _getInstrctorEarningTransactionModel() {
		if(is_null($this->instrctorEarningTransactionModel)) {
			$this->instrctorEarningTransactionModel = new Account_Model_User_InstructorEarningTransaction();
		}
		return $this->instrctorEarningTransactionModel;
	}



	public function _getvalidateModel(){
        if(is_null($this->validateModel)) {
            $this->validateModel = new Account_Model_User_Validate();
        }
        return $this->validateModel;
    }

    public function _getReviewModel(){
        if(is_null($this->reviewModel)) {
            $this->reviewModel = new Catalog_Model_Product_Review();
        }
        return $this->reviewModel;
    }

    protected function _getEmailNotificationModel() {
		$this->emailNotificationModel = new Application_Model_Email();
		return $this->emailNotificationModel;
	}

	public function getSession() {
        return new Zend_Session_Namespace("ad-user");
    }

}